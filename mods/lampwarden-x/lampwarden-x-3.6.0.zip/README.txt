Lampwarden EXPERIMENTAL v3.6.0
==============================

This is the redesign of the game, as a test build. The stable version (2.5.1) stays in yutakhub as
"Lampwarden"; this one installs separately and keeps its own save.

What is in this build
---------------------
- Two playable characters: the RANGER and the SORCERESS. Monk and Witch come in later builds.
- The old weapons, items and perks are gone. Three things replace them:

  SKILLS     The Ranger has 8 skills and uses 4 at a time. They go off on their own.
             Every skill has tags (Lightning, Cold, Fire, Poison, Projectile, Area, Duration...).
  SUPPORT    Come from level-up cards and go into a skill. They change it: more arrows, forking,
  GEMS       chaining, a wider area, a second element... Each gem sits in one skill only.
             Move them around with the "SKILLS & GEMS" button in the shop.
  EQUIPMENT  10 slots: bow, quiver, helmet, body armour, gloves, boots, belt, amulet, 2 rings.
             Normal / Magic / Rare / Unique. Bought in the shop, dropped by chests.
             Spare pieces go to the bag (15 places). Click a bag piece to equip, right-click to sell.

New in 3.6.0
------------
- CONTINUE WHERE YOU LEFT OFF: a solo run is saved by itself between waves. Main menu > Solo >
  "CONTINUE" at the top. Leave in the middle of a wave and you come back to the preparation
  before it, with what you bought and built. The save is removed when the run ends. Co-op runs
  are not saved.
- THE COMPARISON was rewritten without the table: "This piece gives", "You gain" and "You lose".
  A bonus both pieces have reads "lightning damage: +25% → +24%", old to new.

New in 3.5.0
------------
- SKILLS & GEMS is a page of the shop now and fits the screen: skills with their four sockets on
  the left, loose gems on the right (they scroll down instead of growing sideways). Point at a gem
  to read what it does, which of your skills it fits, and to socket it with one click.
- THE COMPARISON is a table: one row per bonus with the value on offer, the value you wear and
  the difference. It fits without scrolling. The inventory shows the same table for bag pieces.
- THE BENCH: currencies are small tiles with their counts; the ones you can use are lit.
- Turret names are no longer cut off. Level-up cards and the vendor say which of your skills a
  support gem fits.
- TURKISH LETTERS in headings no longer come out bolder than the rest.

New in 3.4.0
------------
- SECOND CHARACTER: the SORCERESS, a blood mage. Pick her in the main menu.
  * Her skills cost a share of her life (a cast never takes the last point).
  * Enemies she kills leave BLOOD ORBS. An orb heals; life above full becomes OVERFLOW, which
    takes damage first, fades when it is not fed and makes blood skills hit harder while it lasts.
  * 8 skills: Blood Lance, Blood Pool, Blood Nova, Leech Tendrils, Boiling Blood, Crimson Moon,
    Exsanguinate, Blood Rite. Ability [Q]: Crimson Tide.
  * How they connect: in your Pool casts are free and the Nova is wider; the Nova bursts the orbs
    on the ground for more damage; the Moon drips orbs and strengthens lances that fly through
    it; what dies boiling bursts and leaves an orb; Exsanguinate hits harder the lower your life;
    the Rite makes everything free for a while.
  * Her own weapons and off-hands, blood affixes, 3 uniques, 3 new support gems (Blood Price,
    Transfusion, Vampiric) and 4 blood passives.
- Swiftness, Heavy Hand, the Infusions, Culling and Precision now fit every skill.
- Equipment drops are for the character you play (bows for the Ranger, staves for the Sorceress).

New in 3.3.0
------------
- VISUAL EFFECTS: poison clouds, explosions, stakes, twisters, frost and fire are round and soft
  now; the square plates are gone. Loot sits in a round glow over a turning ring.
- COLLISION: lamp posts, trees, fences and generators are solid. You don't bump into your own
  turrets. Big enemies push through the small ones and no longer wait in front of a turret; a row
  of turrets in their way gets attacked.
- Currency and gems that fall outside the yard slide to where you can reach them.
- VENDOR: what you wear is always in view. Point at a piece and it is shown next to yours, with
  what you would gain and lose by swapping.
- DPS: live DPS at the top left during a wave; in the shop, last wave's average and peak, the
  change from the wave before and which skill the damage came from.
- RANGER: the Chain, Fork and Pierce gems fitted no skill at all; fixed. Gale Shot now goes to the
  cursor and stays there. Frost Fan and Longshot are stronger.

New in 3.2.0
------------
- TIERS now read the way the genre does: T1 is the best, T5 the lowest. Good tiers can only turn up
  in later waves (T4: wave 4, T3: 8, T2: 12, T1: 16) and stay rare when they can.
- EQUIPMENT no longer drops on the ground; it only comes out of CHESTS. Elites and bosses always
  leave one, other enemies leave a small one now and then. Unopened chests open by themselves
  when the wave ends. Only currency and support gems lie on the ground.
- FOUR NEW VALUABLE CURRENCIES: Ash of Unmaking (removes a bonus), Eclipse Shard (an unpredictable
  change, then the piece is sealed), Crown Star (adds a T1 bonus), Twin Flame (copies a piece;
  the rarest, with its own sound and banner).

New in 3.1.0
------------
- LOOT: enemies drop equipment, crafting currency and now and then a support gem. Walk over it to
  take it. Whatever is left when the wave ends comes to you. In co-op everyone sees their own loot.
- CRAFTING CURRENCY: Spark of Change, Spark of Growth, Kingmaker's Seal, Orb of Turmoil, Star of
  Ascension and the very rare Tear of the Beacon. Pick a piece in the inventory and apply one: add
  a bonus, raise the rarity, swap a bonus or roll all the values again.
- AFFIXES: every bonus has 5 tiers (T1-T5), each with its own range of values. Higher tiers turn
  up in later waves. A piece holds at most 3 prefixes and 3 suffixes.
- The VENDOR now sells support gems and currency too. The shop has three pages: Vendor, Inventory
  & Crafting, Skills & Gems.
- More gold, slightly softer enemy health.

Things that connect (to try)
----------------------------
- Storm Arrow + Storm Stakes: whenever your lightning strikes near a stake, the stake bursts.
- Venom Bloom + Ember Volley: fire sets the poison cloud off.
- Gale Shot: your arrows that fly through the twister split in two.
- "Infusion" gems add a second element to a skill. Frost Fan with Storm Infusion also sets off
  stakes and Shocks.
- Ailments: Shock (the enemy takes more damage from you), Chill/Freeze, Ignite, Poison.

Keys
----
WASD move, mouse aim, Q Tempest Call, SPACE dash, E place turret, R repair, TAB shop, F ready.

Known
-----
- Balance is rough: this is a first pass and the numbers will follow how it plays.
- In co-op, Shock only raises the damage of the player who applied it.
- Map and enemies are the same as the stable version for now.
