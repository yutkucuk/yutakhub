Lampwarden EXPERIMENTAL v3.0.0
==============================

This is the redesign of the game, as a test build. The stable version (2.5.1) stays in yutakhub as
"Lampwarden"; this one installs separately and keeps its own save.

What is in this build
---------------------
- One playable character: the RANGER. Sorceress, Monk and Witch come in later builds.
- The old weapons, items and perks are gone. Three things replace them:

  SKILLS     The Ranger has 8 skills and uses 4 at a time. They go off on their own.
             Every skill has tags (Lightning, Cold, Fire, Poison, Projectile, Area, Duration...).
  SUPPORT    Come from level-up cards and go into a skill. They change it: more arrows, forking,
  GEMS       chaining, a wider area, a second element... Each gem sits in one skill only.
             Move them around with the "SKILLS & GEMS" button in the shop.
  EQUIPMENT  10 slots: bow, quiver, helmet, body armour, gloves, boots, belt, amulet, 2 rings.
             Normal / Magic / Rare / Unique. Bought in the shop, dropped by chests.
             Spare pieces go to the bag (8 places). Click a bag piece to equip, right-click to sell.

Things that connect (to try)
----------------------------
- Storm Arrow + Storm Stakes: whenever your lightning strikes near a stake, the stake bursts.
- Venom Bloom + Ember Volley: fire sets the poison cloud off.
- Gale Shot: your arrows that fly through the twister split in two.
- "Infusion" gems add a second element to a skill. Frost Fan with Storm Infusion also sets off
  stakes and Shocks.
- Ailments: Shock (the enemy takes more damage from you), Chill/Freeze, Ignite, Poison.

Keys
----
WASD move, mouse aim, Q Tempest Call, SPACE dash, E place turret, R repair, TAB shop, F ready.

Known
-----
- Balance is rough: this is a first pass and the numbers will follow how it plays.
- In co-op, Shock only raises the damage of the player who applied it.
- Map and enemies are the same as the stable version for now.
