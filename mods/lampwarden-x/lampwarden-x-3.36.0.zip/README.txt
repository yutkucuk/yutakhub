Lampwarden v3.36.0
=================

This is the game now. The old 2.5.1 has been retired from yutakhub (it is being simplified into a
separate Android game).

What is in this build
---------------------
- Four playable characters: the RANGER, the BLOOD MAGE, the MONK and the WITCH.
- The old weapons, items and perks are gone. Three things replace them:

  SKILLS     Every character has 8 skills and uses 4 at a time. They go off on their own.
             Every skill has tags (Lightning, Cold, Fire, Melee, Area, Duration...).
  SUPPORT    Come from level-up cards and go into a skill. They change it: more arrows, forking,
  GEMS       chaining, a wider area, a second element... Each gem sits in one skill only.
             Move them around on the "SKILLS & GEMS" page of the shop.
  EQUIPMENT  6 slots: Weapon, Off-hand, Armour, Amulet, 2 Rings. Normal / Magic / Rare / Unique.
             Bought in the shop, dropped by chests. Spare pieces go to the bag (8 places).
             Hover a piece: [E] wear, [S] sell.

3.36.0: THE END SCREEN, A SCOREBOARD, THE REVIVE RING, A STEADY INTERFACE, CORSAIR AND WITCH UP
  * A lost run slows for a second, loses its colour and freezes; the title and then the table come down over the
    still black-and-white picture. (A won run keeps its colour.)
  * Scoreboard: a column for every player: damage dealt, biggest hit, enemies slain, elites and bosses, critical
    hits, damage taken, healing, times down, friends helped up, distance run, gold earned, time outside the light.
    A title for what each one stood out in, and a star for the most valuable. Every machine counts its own hero
    and tells the others.
  * Helping up: the circle under a downed friend fills from the middle outwards, and the helper sees it too.
  * The crosshair is drawn above every window. The turret window keeps every line in its place.
  * The lobby always shows four seats and nothing in it moves when somebody joins, readies up or leaves. The shop
    never shrinks while it is open; the selected piece sits in a box of a set height.
  * Corsair: Chain Lash can be cracked while the anchor is in the air or coming back; Lash 72 -> 84; levels 4 to 7
    of his skills give more; Ground Swell 35% -> 45%.
  * Witch: +5% damage for every Hush on an enemy (up to 4), sleepers take 50% more (was 35%), pops hit for 90% of
    the blow (was 50%), base damage up 10-25%, levels 4 to 7 give more.

3.35.0: THE CORSAIR TONED DOWN, A SLOWER PISTOL, AND A SHOT COUNTER
  * Shot counter: under the Corsair's feet, one ball for every shot the pistol holds. A full ball is a shot left, a
    ring is a spent one; when both are gone a bar runs under them and the rings fill as he loads.
  * The pistol is slower: 0.75 s between the two shots (was 0.42), 4.2 s to load (was 3.2). Attack speed loads it
    only half as much faster as it speeds other skills. Damage 46 -> 38.
  * Heave Ho damage 40 -> 30. Dragging deals 30% of it (was 50%), the trailing chain cuts a third less, the haul
    back hits for 80% (was 90%). Drop Anchor 140 -> 125.
  * Both weapons gain a little more per level.
  * Measured, starting pair, single target / crowd: standing 59/230 -> 45/205, running 103/272 -> 53/223.

3.34.0: THE CORSAIR'S ANCHOR NO LONGER JUMPS, AND DRAGGING IT IS THE WEAPON
  * The anchor is one object now: every skill takes it from where it is and moves it there. No more leaping from
    skill to skill.
  * Heave Ho is one motion: up from behind, down on the cursor, and dragged back to his heels. Cooldown 1.0 -> 1.9 s,
    damage 30 -> 40, so the anchor spends most of its time trailing.
  * Dragging hits harder (half of Heave Ho's damage, was 30%) and the chain between cuts and slows as well.
  * Capstan Turn lifts it from where it trails and sets it down there again. Drop Anchor: it stays 4 seconds, then
    comes back by itself; Heave Ho throws it on from where it lies.

3.33.0: THE BOSUN IS NOW THE CORSAIR (the fifth hero reworked)
  * A pirate now: cocked hat, eye patch, black beard, red sash. He starts with two weapons, each in a skill slot.
    The anchor is no longer carried: he drags it behind him on its chain and it hurts what he walks it over; Heave Ho
    throws it from there and hauls it back. In his other hand a Flintlock: two shots, then a long reload (3.2 s); a
    ball goes through three enemies, and sets off a Powder Keg it passes.
  * Rebalanced for two weapons: +40 health, +2 armor, +30% knockback.
  * New sounds (pistol, reload, the anchor dragging, a bar of a shanty), new animations (aim and recoil, reload).
  * New items: Powder Horn (off-hand) and the unique Pepperbox (2 more shots to a load).

3.32.0: A FIFTH HERO: THE BOSUN
  * New hero: the BOSUN, a ship's anchor on forty feet of chain. He throws it out and hauls it home. What sets him
    apart: while the anchor lies out the chain between him and it is drawn tight and cuts and slows whatever it
    touches, so where you walk is an attack; go too far and the anchor drags behind you.
    +50 max health, +3 armor, +40% knockback, 4% slower.
  * Eight skills: Heave Ho, Chain Lash, Capstan Turn, Drop Anchor, Undertow, Breaker, Powder Keg, St. Elmo's Fire.
    Ability [Q]: Broadside.
  * His own model, animations, 34 sounds, a voice in the score (squeezebox and fiddle), crosshair, and pages in the
    menu and the Guide.
  * New in the item pool: 4 anchors, 3 off-hands, 3 bonuses (anchor damage, taut chain damage, chain length),
    2 support gems (Ground Swell, Dead Weight), 2 passives and 4 uniques (Forty Fathoms, The Sounding Lead,
    The Drowned Bell, and Breakwater Plate for every hero).

3.31.0: ENGINE UPGRADE (the stutter with high-Hz mice)
  * The game is now built with Godot 4.7.2. On Windows, 4.7.1 had a known engine bug that dropped the frame rate while
    a mouse polling at 2 kHz or more was moving; 4.7.2 fixes it.
  * IMPORTANT: Lampwarden.exe changed as well as Lampwarden.pck. Both have to be updated together (yutakhub does).
  * The [F3] line now shows the engine version: "engine 4.7.2-stable" means the new engine is running.

3.30.0: A GUIDE IN THE MAIN MENU
  * GUIDE, a new page in the main menu, read from the tables the game plays by: the heroes with their ability and
    eight skills, the 25 support gems, equipment (kinds, rarities, every bonus with its T5 and T1 range), all 38
    uniques, the bench's currencies, the 13 defences, weather and special nights.
  * The stutter with 4 kHz+ mice is a known bug of the engine version the game uses (Godot 4.7.1, Windows), fixed in
    Godot 4.7.2. NOT fixed in this version: the engine has to be upgraded. Until then 1000 Hz avoids it.

3.29.0: BOSS BALANCE, BUY-BACK AND THE BAG, WHICH RING, SANDSTORM, AGAINST THE STUTTER
  * Boss life with 3 and 4 players: x3.1 -> x2.5, x4 -> x2.9. A boss that is all that is left of its wave weakens:
    every blow counts for more, up to five times.
  * SOLD: whatever is sold can be bought back for what it fetched until the wave starts. Four extra bag places
    while the shop is open; what is left in them when the wave starts is sold (and can be bought back next time).
  * Two rings: [E] makes the better swap and the estimate shows that swap; [1] / [2] choose by hand.
    [E] on a worn piece takes it off.
  * Weather by map: the Caravan's Rest has no rain; its SANDSTORM leaves you only what is close and blinds the map.
    The Pass's blizzard whites out the far side of the yard.
  * Stutter: shadows cost half as much and have their own setting. [F3] shows frames a second, the longest frame
    and mouse messages a frame.

3.28.0: SHADOWS FROM THE SKY, CONES OF LIGHT UNDER THE LAMPS, THE RAIN DONE AGAIN, FIXES
  ATMOSPHERE (Settings > "Soft glow and colour" turns all of it off)
  * SHADOWS: whatever stands (trees, posts, tents, the Beacon, heroes, enemies, defences) throws a shadow on the
    ground in the light of the sky, to its right. Faint under a lamp, plain in the dark.
  * A faint cone of light in the air under every lamp. What is further off is a touch cooler and dimmer.
  RAIN (done again)
  * It falls over the whole picture now, however far out the camera is: fine slanting streaks at three depths.
  * The ground gets wet: darker, with puddles that give the lamps back as wavering streaks.
  * The SOUND is new: no hiss, no ticking; a low, muffled rain. Quieter, thunder rarer.
  * Sand wind and blizzard cover the whole view as well.
  BALANCE AND FIXES
  * Blood Lance: damage 20 -> 28. Every defence has 15% less life. The pillar of light over a chest is a hair now.
  * Breakwater: the Beacon's Wrath [X] no longer lights lamps that are out (except in Blackout). Lamps a boss put
    out catch again after half a minute; on a Sea Fog night, when the wave is over.
  NOT TRIED: hearing any of it, how it looks in motion, speed on Windows.

3.27.0: CO-OP FOR UP TO FOUR PLAYERS
  * Co-op takes up to 4 players now. One hosts, up to three friends join (Steam invite or IP). Everybody has a line
    in their own colour in the lobby; the host starts when all guests are ready.
  * In the game: name, level and life of the other three at the top right, names over heads, arrows at the screen
    edge, four dots on the minimap, chat to everybody. Anybody can pick up a player who is down.
  * If somebody drops out the rest carry on; what they built goes to the host. Nobody can join while a run is on.
  * DIFFICULTY BY NUMBER OF PLAYERS (1 / 2 / 3 / 4): enemies x1 / 1.7 / 2.3 / 2.9, their life x1 / 1.45 / 1.8 / 2.1,
    boss life x1 / 2.1 / 3.1 / 4, their damage x1 / 1.1 / 1.15 / 1.2. Two is what it was; three and four are a guess.
  * The co-op save works with four: a player with no part in the save starts with a card for every wave missed.
  * Fixed (from 3.26.0): a guest could get one level-up card too many when a run was picked up again.
  TRIED: 2, 3 and 4 instances on one machine over IP. NOT TRIED: Steam lobbies and P2P between real computers,
  real latency, the balance with four real players.

3.26.0: CO-OP RUNS ARE SAVED AND CAN BE PICKED UP AGAIN
  * A co-op run is saved now (on the host's computer, in a file of its own, apart from the solo run), between
    waves as in solo: when a wave ends, when the next begins, and on leaving to the menu during preparation.
  * Everybody's own part is in it: skills and their gems, gear, bag, gold, level, defences. A guest hands it to the
    host at the start of each preparation, on readying up and on leaving.
  * TO CONTINUE: the same player hosts, the friend joins and readies up; "CONTINUE • wave N, map, difficulty" is
    at the top of the co-op page. Everybody plays the hero they had in that run.
  * If your friend drops out in the middle, the save is kept. It is deleted when the run ends.
  * Two at one computer (split screen) is not saved.
  * Fixed: a guest who switched "ready" off and on again was paid the end-of-wave gold again.
  TRIED: two instances on one machine: save, quit, start again, continue. NOT TRIED: two real computers over Steam.

3.25.0: WEATHER AND RAIN, LIFE LEECH AND 11 NEW UNIQUES, A NEW SOUND FOR THE TEAR, EFFECT CLUTTER KEPT DOWN
  WEATHER (some nights; announced in the preparation, lasts that wave)
      Breakwater      RAIN       burning lasts a quarter shorter, Shock a quarter longer. Sheet lightning far off.
      Caravan's Rest  SAND WIND  enemies that shoot do so a quarter less often, Chill wears off sooner. Rarely, rain.
      Pass            BLIZZARD   Chill and Freeze last a quarter longer, burning a quarter shorter.
    The effects are small on purpose; it is mostly there to be seen and heard. The rain has its own sound.
  ITEMS
  * LIFE LEECH: a new stat. A share of the damage you deal comes back as life (at most 8% of your life a second).
    The "Leeching" bonus on weapons, amulets and rings. "Reaping": a chance to heal on every kill.
  * 11 new uniques (38 in all): The Red Tithe, Gravewine Chalice, Butcher's Apron, Cinder Maw, Hourglass of the
    Second Breath, Phoenix Pin, Glass Covenant, Stillwater Loop, Executioner's Due, Gambler's Knuckle, Warden's Oath.
  SOUND
  * The Tear of the Beacon falls with a new sound: the air drawn in, one heavy blow, a chord of horns and voices,
    one note of glass ringing on over it. 6 s instead of 3.5. NOT HEARD BY ME, only measured.
  EFFECT CLUTTER
  * When a great deal is alight at once, new effects are drawn fainter by themselves (by up to 45%) and come back
    when it calms down. Enemy warnings, shadows and numbers are never touched.
  * In co-op the other player's skill effects are drawn fainter than yours (60%).
  * Two sliders in Settings: "My skill effects" and "Others' skill effects".
  OTHER
  * The pillar of light over a dropped item dies down slowly after 10 s; the gem, its glow and its shadow stay.
  * HARD is a touch easier: enemy life and damage down by about 6%.
  NOT TRIED: hearing any of it, the rain in motion, Windows.

3.24.0: SOFT BLOOM, AN EDGE OF SKY LIGHT IN THE DARK, A GRADE FOR EACH MAP, THE PARTS STUCK IN THE BREAKWATER'S TOWER
  LOOK (all of it kept gentle; Settings > "Soft glow and colour" turns it off)
  * BLOOM: things that give light (the Beacon's glass, street lamps, the campfire, gems, spells) spill a soft
    light around themselves. Only light sources bloom; the ground, carpets and creatures do not, and no
    colour is washed out.
  * EDGE LIGHT: where no lamp reaches, the hero, enemies and the pet no longer sink into black: a cold
    light from the sky lies on their heads and shoulders. It goes as soon as lamplight takes over.
  * GRADE: each map has its own air. Warm lights and bluish shade at the Caravan's Rest; cold sea air and
    warm lamps on the Breakwater; a pale, clear snow light on the Pass.
  FIXED
  * The dark arm and rope sticking out of the Beacon on the Breakwater were the jib and rope of the hand
    crane on the quay, drawn at the middle of the map. The same mistake had put the signal gun's barrel, the
    capstan's bars, the buffer's braces, the arms of the tall lamp standards and the signal mast's wires
    inside the tower. All of them are where they belong now.
  * The Pass had it too: the campfire's logs, the poles by the tent and the braces of the lamp posts stood
    inside the Beacon. Fixed.
  NOT TRIED: speed on Windows (hence the setting), how it looks in motion.

3.23.0: SUPPORT GEMS TUNE YOUR DEFENCES, ENEMIES STRIKE INSTEAD OF WALKING ON THE SPOT, SHADOWS UNDER WHAT LIES ON
THE GROUND. A support gem socketed in one of your skills now also tunes the defences you built yourself, in a small
way and without the skill's drawback: Volley (a second shot for 25%, one more moth), Chain (a Lantern Post's spark
bounces once for 35%, the Storm Vane jumps once more), Fork (two splinters for 15% each), Pierce (one more enemy),
Widen and Focus (reach and damage of the Kiln, Bell, Candles and Bellows), Linger (coals and slow last longer),
Overcharge (the Storm Vane can Shock), Deep Freeze (the Bell freezes more often), Kindling (stronger burns), Virulence
(the Thornhedge poisons), the three Infusions (Lantern Posts, Ballistas and Moth Cages shock, chill or ignite),
Culling (defences finish what is under 5%), Echo (10% chance to fire again). Swiftness, Heavy Hand, Precision, Blood
Price, Vampiric, Flowing Strikes, Aftershock, Momentum and Soporific do nothing for a defence. The gem's text says
"Your defences: ..."; the vendor names what tunes each defence. ENEMIES: one that has reached the Beacon, a defence
or a hero stops striding and strikes in its own way (claws, a bite, fists from overhead, a ram, a slime throwing
itself, a swoop, a mace); Spitters and Lobbers kick back when they shoot. SHADOWS: a faint one under gems, drops,
chests and enemy shots, so they stand out on any ground. Not verified: how the motion reads at speed, Windows, two
real players; the tuning numbers are a first guess.

3.22.0: THE CARAVAN'S REST IS BIGGER: OPEN SAND TO FIGHT ON. The map is about a quarter larger each way (116
across instead of 92, 59% more ground). The camps stand further out: the great tent, the well, the market, the
carpet seller, the camels, the drovers' fire and the pool. Round the Beacon there is clear sand out to about 24
(the nearest thing used to stand at 16). The safe zone is 28 instead of 24, the fire bowls stand at 36 instead
of 30, every trail has a fourth lantern. FIX: an enemy could get caught between the pool and a palm at its edge
and the wave would not end; those palms now stop a hero only, and on every map an enemy held against scenery
for far longer than going round takes now walks through it. Note: the horde takes a few seconds longer to
arrive and there is more room to run, which makes the map somewhat easier; no difficulty numbers were changed.

3.21.0: A NEW MAP, "THE CARAVAN'S REST", A NEW LORD OF THE DARK, AND A RUN THAT GETS HARD SOONER
  THE CARAVAN'S REST (replaces Crossroads, built from nothing): an oasis on the Silk Road, a night in the
  13th century. No wall, no road: they come over the dunes from EIGHT DIRECTIONS (two opposite ones in
  wave 1, all of them from wave 10). Seljuk star tiles under the Beacon, a brick fire tower with a
  turquoise dome, carpets, tents, a spice market, camels, a pool under date palms. Things that move: a
  caravan passing all night, the sweep of the well, strings of pennants, palms, sand and fire.
  FIRE BOWLS stand where the generators stood: the wind puts them out, you stand by one to light it.
  Its music layer is new (santur, reed pipe, oud, hand drums) and so is its ambience (desert wind,
  fire, crickets, far-off camel bells). I cannot hear either of them.
  THE LORD OF THE DARK was rebuilt: a robe with no feet, an empty hood, antlers, a dying star caged in
  his chest, an eclipsed sun behind his head, a scythe of light, a snuffed lantern. Same moves.
  DIFFICULTY: waves 5 to 12 are clearly harder (enemy and boss life up to +55%, numbers and damage a
  little), the last waves nearly unchanged. TWO PLAYERS: count x1.7 (was 1.5), life x1.45 (was 1.25),
  boss life x2.1 (was 1.6), damage +10%.
  THE BREAKWATER: the Beacon's Wrath [X] takes nobody's bonuses now: a twentieth of a boss's life, a
  quarter of anything else. What it kills does not charge the next one. The quay is longer (58 > 66).
  ORBS: Turmoil works 5 times on one piece, the Tear of the Beacon twice.
  BLOOD MAGE: costs up, orbs rarer (8%) and smaller (3.5%), her own pool halves costs instead of
  removing them, regeneration halved. Under half her life she holds back every spell but the Lance;
  under a third the Lance is free. A boss sheds orbs while she keeps hitting it.
  UI: a menu panel taller than the screen is drawn smaller so nothing is cut off.

3.20.1: NO BOSS MOVE HURTS A DEFENCE. The marks are wide, and whatever stood in them melted. None of the special
moves (leap, slime, charge, hammerfall and its waves, jets, stingers, acid, falling night, shadow step, eclipse,
the sword stroke) damages turrets, walls or any other defence any more, and "lights out" no longer throws its ring
of bolts. The only move that touches the Beacon is the Colossus running into it. A boss still hits a defence with
its ordinary blows when it reaches one. Tested: 15 defences standing inside every move of every boss lose nothing.

3.20.0: THE BOSSES HAVE MOVES OF THEIR OWN. Everything a boss does is drawn on the ground before it happens:
the whole shape from the first moment, filling up until it lands. Walk or dash out of it (nothing hurts you
in the middle of a dash). The name of the move shows under the boss bar; warnings are drawn over wheat,
fences and houses. The old generic attacks (bullet rings, spirals, random bombs, the sprint, summons) are gone
from the bosses. SLIME KING: Royal Leap (jumps onto you; a slowing puddle and slimes where he lands; three
hops below half health), Slime Rain (lobbed globs that leave slowing puddles). IRON COLOSSUS: Furnace Charge
(a marked lane to the wall, or into the Beacon if it is in the way; he is winded afterwards), Hammerfall (the
ground at his feet, then shock waves rolling out: dash through them), Furnace Jets (four jets turning round
him; they reverse half way below half health). HIVE MOTHER: Brood (eggs you can tread on before they hatch),
Stinger Volley (fans of five lanes, re-aimed each time: stand between them), Acid Breath (a cone, and acid
that stays). LORD OF THE DARK: his sword stroke and "lights out" stay; Falling Night (the sky comes down
where you stand, ten times: keep moving), Shadow Step (sinks and comes up behind you, sword rising), Eclipse
(everything burns except the ground at his feet: run TO him; below half health the ground at his feet goes
next). Tested: 59 checks of hit / dodge / state for every move, bot fights against all four on two maps, a
two-process co-op run in which host and guest saw the same 24 moves in the same order. Not tested: by hand
(the feel and the warning times), by ear, on Windows, with two real players.

3.19.0: CONTROLS PAGE (Settings > Controls, also in the pause menu): every keyboard action and the
gamepad's fight buttons can be moved; a key or button already in use changes places. Button names can
follow an Xbox, PlayStation or Nintendo pad (automatic by default); the bar and the texts follow.
WHY THE GAMEPAD STOPS WITH STEAM OPEN: this build runs on Steam's shared test ID (480, Spacewar), whose
Steam Input setting is on, so Steam takes the pad once the game registers with it. Until the game has
its own ID: Steam library > Spacewar > Properties > Controller > Disable Steam Input (steam://install/480
if it is not listed). The CO-OP page says so. Not tried here: Steam, a real pad.

3.18.0: A GAMEPAD IS NOW A GAMEPAD, NOT A MOUSE. In menus and panels the D-pad or the left stick steps from
control to control (a frame marks the one with the focus, its description opens beside it), (A) chooses,
(B) goes back, the right stick scrolls, LB / RB change the shop's tab, and (X) / (Y) do what the control
under the focus offers: lock or reroll at the vendor, sell or wear in the inventory, reroll on the level-up
cards. A bar along the bottom of the screen draws the pad's buttons with what each does right now. In a
fight: left stick move, right stick aim, (A) dash, (X) ability, RT the Beacon's Wrath, (Y) ready, LB build,
RB repair, LT the defence next to you (upgrade / move / sell), Back shop, Start pause. Placing a defence:
the right stick moves a mark on the ground, (A) puts it there, (B) cancels. R3 in a panel is the old free
pointer, kept as a way out. Texts name the pad's buttons while a pad is in use, the tutorial included.
SPLIT SCREEN: the shop is no longer shrunk: in half a screen its sidebar lies under the page as four
columns and the panel is full size; the shared map hides while a shop, cards, a menu or the end screen is
open in either half; a pad player now gets the descriptions and comparisons a mouse gets. The credits page
was empty (a formatting slip) and is back. Not tried: a real gamepad with this layout, Windows.

3.17.2: for a gamepad that did nothing at all (cause not known; still not tried with a real pad): Steam
is no longer started when the game opens, only when the CO-OP page is opened (so open that page once
before sending or accepting a Steam invitation); pads are asked for their state every frame, whatever
events arrive and whichever window is thought to be in front. "Kol Testi.bat" opens a plain screen
that shows the pads the game sees, live, asks Windows what is plugged in, starts Steam five seconds in
to see whether the list changes, and closes after 30 seconds; all of it goes to gamepad_log.txt next
to the game. Split screen: the pad pointer follows the scaled-down shop exactly.

3.17.1: on the SAME SCREEN page a gamepad is paired by pressing a button on it, and a line shows every
gamepad the game can see with its live buttons and sticks. Split screen: the interface in each half is
a third larger (the shop shrinks itself to fit) and the two minimaps are one shared map at the top.

New in 3.17.0: GAMEPAD SUPPORT AND TWO PLAYERS ON ONE SCREEN
-----------------------------------------------------------
- GAMEPAD, everywhere (menus, solo, online co-op, same screen). The layout changed in 3.18.0 and is
  described there. Alone you can change between keyboard-mouse and gamepad at any moment. The pad
  rumbles when you are hit.
- SAME SCREEN (new entry in the main menu): the screen is split down the middle, each half a whole
  game of its own (camera, shop, cards, inventory), talking to the other exactly as online co-op
  does. Each player picks a hero and keyboard + mouse or a gamepad. Embers and stats are written once.
  The interface in each half is about 57% of its usual size; the computer runs two games at once.
- Not tested: a real gamepad (signals were generated in software, Xbox layout), Windows.

3.16.1: the Reroll button now sits right above the goods it rerolls ([R] still works).

New in 3.16.0: NEW DEFENCES, THE TEAR, A LORD WHO USES HIS SWORD, A HIVE MOTHER WHO IS A BEE
-----------------------------------------------------------------------------------------
- THE TURRETS ARE GONE (Lepetos stays). Twelve defences replace them, built from what a lampwarden
  has: Lantern Post, Thornhedge, Candle Ring, Rime Bell, Cinder Kiln, Ember Bellows, Storm Vane,
  Watchfire, Wayshrine, Ballista, Moth Cage, Beacon Mirror. Each has its own model, moving parts and
  sound. New mechanics: the Watchfire (enemies in its light take 18% more damage from everything, and
  the circle counts as lit, as does the ground round a Lantern Post), the Moth Cage (homing moths, one enemy each), the Kiln leaves burning ground,
  the Thornhedge hurts what leans on it, the Ballista pierces 3, the Bell tolls instead of humming,
  the Mirror takes its ray from the Beacon itself. Old saved runs are converted.
- THE TEAR OF THE BEACON is bright cyan, stands under an 18 m pillar of light with a light of its own,
  has its own (loud) sound, ducks the music, and is marked on the minimap. Drops now announce
  themselves by value: Rare a thin shaft, Unique a pillar and a light, the Tear above all.
- THE LORD OF THE DARK swings his sword: a wide arc is marked on the ground and fills for one second,
  then the blade goes through it. Walk or dash out; behind him is safe. Below half health a quicker
  backhand follows. THE HIVE MOTHER is redrawn as a bee.
- Fixed: after a boss charged, its attack list started over, so the attacks at the end never came.
- THE BREAKWATER: nothing there mentions generators any more. Blackout nights never come there; Sea
  Fog does (real fog on screen), and the Beacon's Wrath burns it off. The lamps relight after a wave.
- Reroll sits fixed in the top row of the shop, and [R] rerolls. A crosshair of its own for every
  character replaces the mouse pointer in play. The Great Light is now The Beacon's Wrath, on [X];
  its damage is no longer counted in your DPS. Time spent down: 5.9 s at wave 1, 4 s at wave 20
  (was 6.4 to 14 s).
- Not tested: how any of it sounds, how it moves, Windows, two real players.

New in 3.15.1: SMACKS, CRACKLE, TOUGHER ENEMIES
-----------------------------------------------
- Every melee hit is heard: six takes (three bright slaps, three dull punches), a slam under the big ones.
- Lightning crawls over what it hits, forks to what stands near (for show), and has new sounds.
- Enemy health: Easy 0.18 -> 0.24, Normal 0.58 -> 0.80, Hard 0.82 -> 1.25, Nightmare 1.25 -> 2.1.

New in 3.15.0: HIT FEEL, COMBOS, MUSIC FOR EACH MAP AND EACH CHARACTER
---------------------------------------------------------------------
- An enemy that is hit recoils along the blow and swells for an instant; sparks fly on in the
  direction of the hit; the body gives its own sound (thud, thock or pat, several takes each),
  a crack on a critical hit; the dead are thrown and tumble. Melee nudges the camera and the
  striking arm bites for a moment before it follows through.
- MONK: Staff Sweep is a chain of five ending in a somersault. The other three cycle gestures.
- Each map has its own arrangement, and the tune is played by the character's own instrument.

New in 3.14.1: THE WITCH'S OWN MOVEMENT, HOW SLEEP LOOKS, BALANCE
----------------------------------------------------------------
- Eleven clips of her own: idle, run, one gesture for each of her eight skills and for Good Night.
- A sleeper is lilac, slumped and breathing, not ice blue.
- Balance: sleep 1.6 -> 1.3 s, pops hit less, Good Night 18 -> 22 s, early skills down, Lullaby and Bad Dream up.

New in 3.14.0: THE FOURTH CHARACTER, THE WITCH
----------------------------------------------
A quiet caster: moths, spores, wind chimes, bubbles. Her sounds are whispers, wings and soft pops.
- HUSH: her skills lay Hush. At 4 an enemy falls asleep and she hits it 35% harder. Anything that
  dies hushed or asleep pops, hurting what is near and hushing it in turn; pops chain, and each
  one in a row sounds a step higher.
- 8 skills (Moth Lantern, Spore Bloom, Lullaby, Wind Chimes, Dew Bubbles, Bad Dream, The Hushed
  Hour, Veil of Moths), the ability Good Night, her own gear, 3 uniques, 2 passives, 1 support gem.

New in 3.13.0: CHARACTERS, ITEMS AND BUILDS GONE THROUGH AGAIN
--------------------------------------------------------------
All 24 skills were measured one by one (level 1 and 7, one tough target and a crowd of 24), then
as kits of four. What the numbers said: the lightning Ranger did twice what anyone else did, the
Monk hit a single target for a third of that, the Blood Mage sat in between.
- MONK up: Staff Sweep 14 -> 16.5, Frost Palm 72 -> 108, Spark Fists 9 -> 12.5, Gale Kick 30 -> 37,
  Resonant Gong 14 -> 19, Falling Sky 170 -> 205, Frost Image 14 -> 17. Each Ki held: 5% damage (was 4).
- BLOOD MAGE (the Sorceress's name from now on) up: Blood Lance 17 -> 20, Blood Nova 26 -> 34 and
  2.4 -> 2.2 s, Exsanguinate 80 -> 96, Leech Tendrils 7 -> 8.5, Blood Pool 7 -> 8, Crimson Moon 10 -> 11.5.
- RANGER: Frost Fan 16 -> 20, shards 75% -> 85%. Storm Stakes 14 -> 12.5, Storm Arrow's arcs 60% -> 55%.
- 6 NEW UNIQUES (24 in all): Warden's Tally, Moonwake, The Long Thirst, Ashen Heart, Mantle of the
  Iron Lotus, Stormcaller's Wraps.
- NEW AFFIX on weapons: "+1 to the level of Physical skills" (rare).
- Item and gem texts fit every class now ("shots", not "arrows"). Hunter's Jerkin is Padded Jerkin.

New in 3.12.0: THE CROSSROADS AND THE PASS, REBUILT
---------------------------------------------------
The two old maps were rebuilt to the standard of the Breakwater. What you play on is the same
size (roads, generators, lamps, gates); the world it stands in is new.
- THE CROSSROADS is a village at night: cobbled roads, a square with a compass rose, and four
  places in the four corners: the MILL (its sails turn) and two houses, the WHEAT FIELD and the
  kitchen garden, the POND (rings on the water, reeds, fireflies), the BURIAL GROUND.
- THE PASS is a mountain road in the snow. Snow falls. A WATERFALL comes down the rock wall, the
  beck goes under the road and over the edge. Below the drop a slow SEA OF CLOUD. The road comes
  in over a TIMBER BRIDGE in the west and goes into a TUNNEL in the east.
- Wind you can see: tree tops, reeds, wheat, washing and pennants move.
- Every map has its own ambience.
- FIX: an enemy caught between two posts of a fence, or between a house and the barrel beside it
  (the wave never ended). Going round obstacles was reworked and tested for every enemy kind.

New in 3.11.0: NEW SOUND, NEW MUSIC, ONE THEME, A NEW MENU
----------------------------------------------------------
- EVERY SOUND EFFECT IS NEW (114 of them): real instrument samples mixed with air, impact, water
  and fire built in code. Frequent sounds are small, soft and come in several takes; rare ones are
  big. Levels are set by kind of sound and a limiter sits on the output.
- Gems and blood orbs picked up in a row climb a scale.
- THE MUSIC IS REWRITTEN: one piece in three layers (D minor). The night watch always plays; drums
  and pulsing strings join when a wave is on; brass, voices and piano when a boss is here or the
  Beacon is failing. The music steps back for a moment under a big sound.
- ONE THEME: ink-dark panels, brass frames, parchment text, the Beacon's amber. A carved capital
  face (Cinzel) for titles, Alegreya Sans for everything that is read.
- A NEW MAIN MENU: a list instead of tiles, and the hero you pick stands there alive.

New in 3.10.0: NEW MODELS, JOINTED ANIMATION, THE GREAT LIGHT
-------------------------------------------------------------
(The first part of the big overhaul. Sound, music, the theme, the menu and the two older maps follow.)

- THE HEROES ARE REDRAWN and jointed: body, head, arms, legs, hair, cape, skirt, bow and staff are
  separate parts posed every frame, instead of four swapped frames. Running, standing, dashing,
  going down and every skill have their own movement.
- THE MONK'S LEAP (Q) is a real jump now, and lightning strikes where he lands.
- BLOWS LAND ON TIME: the Monk's sweep, palm and kick deal their damage when the movement connects.
  Heavy hits hold the screen for an instant (solo only).
- ALL 17 ENEMIES ARE REDRAWN, bosses included. Their parts move separately, and they swell white
  and vanish when they die.
- THE BREAKWATER HAS NO GENERATORS BUT THE GREAT LIGHT: the lighthouse charges during a wave (kills
  speed it up). When it is full, [G] sends a wall of light down the quay: damage, burn, slow and
  knockback for everything it passes. In Blackout it also relights the lamps for 40 seconds.

New in 3.9.0: THE BREAKWATER (a new map)
----------------------------------------
A one-sided map. Main menu > Solo (or the host in co-op) > Map: THE BREAKWATER.

- The Beacon is the lighthouse at the tip of a stone pier. Water on three sides; the only way in
  is the wide quay from the town gate to the lighthouse (about 30 m wide, 58 m long).
- THREE ARCHES: the town gate has three arches. Early waves come through one, then two, and from
  wave 6 through all three. Between waves the arches that will open are marked.
- Nothing behind you: the round head of the pier behind the Beacon is closed.
- LIGHT: posts on both kerbs, double standards beside the rails, two lanterns on the gate. With
  the generators running every place you can walk is lit.
- ON THE QUAY: three things to fight round (cargo, the capstan, a tipped cart) and the buffer at
  the end of the rails. Along the edges: crates, barrels, a net rack, a hand crane, an upturned boat.
- THE SEA: its own surface, with lines of swell, foam against the wall and glints where a light
  lies on it. Five moored boats that ride the swell, three channel buoys that flash in turn.
- THE TOWN GATE: a battlemented wall, three arches with their portcullises drawn up, a round
  tower on each side, roofs behind it and a sick green glow coming through.
- The minimap, the enemy-path markers and the ring of light follow this map's shape.
- A quiet loop of sea plays on this map.
- New achievement: Harbour Light (win a run on The Breakwater).
- The other two maps are unchanged.

New in 3.8.0: THE MONK
----------------------
The third character. He fights with a staff and bare hands, right next to the enemy; none of
his skills reach far.

- KI: his blows build Ki (up to 5; shown as dots next to the life bar and as lights circling
  him). Every point he holds: 4% more damage, 2% attack speed, 4% less damage taken. Every point
  he GAINS heals 2% of his life (also when Ki is full). Ki starts to fade after 5 seconds
  without a blow.
- HE STANDS IN THE WAY: enemies notice the Monk from 12 m instead of 9 and come for him instead
  of the Beacon.
- NO SWINGS AT AIR: a melee skill goes off only when something is within reach, and turns to
  the nearest enemy if nothing stands where you aim.
- 8 SKILLS
    Staff Sweep     the starter. A wide arc; every third swing is heavy: wider, harder, throws
                    enemies back, gives 1 Ki
    Frost Palm      one blow at the TOUGHEST enemy in reach; a kill shatters it, the shards hit
                    everything around, 1 Ki
    Spark Fists     four quick blows that arc on and Shock; 1 Ki if all four land
    Gale Kick       hits everything around you and throws it back; 1 Ki for 3 or more
    Resonant Gong   set at the cursor; whenever a melee blow of yours lands within its hearing
                    it rings and sends out a wave of THE SAME KIND as the blow
    Falling Sky     goes off BY ITSELF when Ki is full: spends all of it, a thunderbolt comes down
    Frost Image     an image of ice steps into the fight and strikes around itself; its blows
                    ring the Gong too
    Still Breath    2 Ki and life at once; much harder to hit for 4 seconds
- ABILITY (Q) DRAGON'S LEAP: leap to the cursor (up to 12 m), the ground breaks where you land,
  Ki is filled. This is how you get to Spitters and Lobbers that stand far off.
- 3 NEW SUPPORT GEMS (melee skills only): Flowing Strikes (half again as much Ki), Aftershock
  (30% of a hit goes on to the two nearest enemies), Momentum (3% more damage per Ki).
- EQUIPMENT: four staves, and Prayer Beads, Hand Wraps and a Pilgrim's Sash for the off-hand.
  New bonuses: melee damage, Ki from your blows. Three uniques: Skybreaker (Falling Sky strikes
  twice), Beads of the Quiet Hour (keep 2 Ki after Falling Sky), The Sixth Knot (hold one more).
- His own model, 20 new icons, 15 new sounds, and a crescent trail where a swing went.

New in 3.7.0: SIMPLER
---------------------
- EQUIPMENT: 6 slots instead of 10 (Weapon, Off-hand, Armour, Amulet, two Rings). The bag holds
  8 instead of 15. A piece carries at most 4 bonuses, and bonuses are stronger to match.
- CURRENCY: 4 kinds instead of 10, one rule each:
    Spark of Making     adds a new bonus (rarity rises by itself)
    Orb of Turmoil      replaces the bonus YOU PICKED with a new one
    Eclipse Shard       a gamble: seals the piece, one of four things happens
    Tear of the Beacon  raises the bonus YOU PICKED to the best tier (T1); the rarest drop
  Click a bonus on the bench to pick it. A changed bonus says "NEW" or "was: ...", a removed
  one is listed in red underneath.
- TIERS are read by colour: gold T1, blue T2, green T3, white T4, grey T5. Point at a bonus for
  its tier and that tier's range.
- A BONUS YOU CAN'T USE is dimmed and says so (cold damage with no cold skill, for one).
- ESTIMATED EFFECT: the comparison has one line such as "damage ▲ +8%"; pieces in the bag carry
  a ▲ / ▼ mark. Point at a piece and press [E] to wear it or [S] to sell it; one button
  sells every piece marked ▼.
- The vendor shows 5 offers instead of 7; equipment offers list their bonuses one by one.
- SORCERESS: the Transfusion gem is gone. A spell she can't pay for no longer goes off.
  Overflow, orb healing, Leech Tendrils and Vampiric are weaker.
- Long descriptions fit the level-up cards. Rare piece names read better.
- Runs saved by an older build can't be continued (the equipment layout changed).

New in 3.6.0
------------
- CONTINUE WHERE YOU LEFT OFF: a solo run is saved by itself between waves. Main menu > Solo >
  "CONTINUE" at the top. Leave in the middle of a wave and you come back to the preparation
  before it, with what you bought and built. The save is removed when the run ends. Co-op runs
  are not saved.
- THE COMPARISON was rewritten without the table: "This piece gives", "You gain" and "You lose".
  A bonus both pieces have reads "lightning damage: +25% → +24%", old to new.

New in 3.5.0
------------
- SKILLS & GEMS is a page of the shop now and fits the screen: skills with their four sockets on
  the left, loose gems on the right (they scroll down instead of growing sideways). Point at a gem
  to read what it does, which of your skills it fits, and to socket it with one click.
- THE COMPARISON is a table: one row per bonus with the value on offer, the value you wear and
  the difference. It fits without scrolling. The inventory shows the same table for bag pieces.
- THE BENCH: currencies are small tiles with their counts; the ones you can use are lit.
- Turret names are no longer cut off. Level-up cards and the vendor say which of your skills a
  support gem fits.
- TURKISH LETTERS in headings no longer come out bolder than the rest.

New in 3.4.0
------------
- SECOND CHARACTER: the SORCERESS, a blood mage. Pick her in the main menu.
  * Her skills cost a share of her life (a cast never takes the last point).
  * Enemies she kills leave BLOOD ORBS. An orb heals; life above full becomes OVERFLOW, which
    takes damage first, fades when it is not fed and makes blood skills hit harder while it lasts.
  * 8 skills: Blood Lance, Blood Pool, Blood Nova, Leech Tendrils, Boiling Blood, Crimson Moon,
    Exsanguinate, Blood Rite. Ability [Q]: Crimson Tide.
  * How they connect: in your Pool casts are free and the Nova is wider; the Nova bursts the orbs
    on the ground for more damage; the Moon drips orbs and strengthens lances that fly through
    it; what dies boiling bursts and leaves an orb; Exsanguinate hits harder the lower your life;
    the Rite makes everything free for a while.
  * Her own weapons and off-hands, blood affixes, 3 uniques, 3 new support gems (Blood Price,
    Transfusion, Vampiric) and 4 blood passives.
- Swiftness, Heavy Hand, the Infusions, Culling and Precision now fit every skill.
- Equipment drops are for the character you play (bows for the Ranger, staves for the Sorceress).

New in 3.3.0
------------
- VISUAL EFFECTS: poison clouds, explosions, stakes, twisters, frost and fire are round and soft
  now; the square plates are gone. Loot sits in a round glow over a turning ring.
- COLLISION: lamp posts, trees, fences and generators are solid. You don't bump into your own
  turrets. Big enemies push through the small ones and no longer wait in front of a turret; a row
  of turrets in their way gets attacked.
- Currency and gems that fall outside the yard slide to where you can reach them.
- VENDOR: what you wear is always in view. Point at a piece and it is shown next to yours, with
  what you would gain and lose by swapping.
- DPS: live DPS at the top left during a wave; in the shop, last wave's average and peak, the
  change from the wave before and which skill the damage came from.
- RANGER: the Chain, Fork and Pierce gems fitted no skill at all; fixed. Gale Shot now goes to the
  cursor and stays there. Frost Fan and Longshot are stronger.

New in 3.2.0
------------
- TIERS now read the way the genre does: T1 is the best, T5 the lowest. Good tiers can only turn up
  in later waves (T4: wave 4, T3: 8, T2: 12, T1: 16) and stay rare when they can.
- EQUIPMENT no longer drops on the ground; it only comes out of CHESTS. Elites and bosses always
  leave one, other enemies leave a small one now and then. Unopened chests open by themselves
  when the wave ends. Only currency and support gems lie on the ground.
- FOUR NEW VALUABLE CURRENCIES: Ash of Unmaking (removes a bonus), Eclipse Shard (an unpredictable
  change, then the piece is sealed), Crown Star (adds a T1 bonus), Twin Flame (copies a piece;
  the rarest, with its own sound and banner).

New in 3.1.0
------------
- LOOT: enemies drop equipment, crafting currency and now and then a support gem. Walk over it to
  take it. Whatever is left when the wave ends comes to you. In co-op everyone sees their own loot.
- CRAFTING CURRENCY: Spark of Change, Spark of Growth, Kingmaker's Seal, Orb of Turmoil, Star of
  Ascension and the very rare Tear of the Beacon. Pick a piece in the inventory and apply one: add
  a bonus, raise the rarity, swap a bonus or roll all the values again.
- AFFIXES: every bonus has 5 tiers (T1-T5), each with its own range of values. Higher tiers turn
  up in later waves. A piece holds at most 3 prefixes and 3 suffixes.
- The VENDOR now sells support gems and currency too. The shop has three pages: Vendor, Inventory
  & Crafting, Skills & Gems.
- More gold, slightly softer enemy health.

Things that connect (to try)
----------------------------
- Storm Arrow + Storm Stakes: whenever your lightning strikes near a stake, the stake bursts.
- Venom Bloom + Ember Volley: fire sets the poison cloud off.
- Gale Shot: your arrows that fly through the twister split in two.
- "Infusion" gems add a second element to a skill. Frost Fan with Storm Infusion also sets off
  stakes and Shocks.
- Ailments: Shock (the enemy takes more damage from you), Chill/Freeze, Ignite, Poison.

Keys
----
WASD move, mouse aim, Q character ability, SPACE dash, E build a defence, R repair (in the shop: reroll),
X the Beacon's Wrath (Breakwater), TAB shop, F ready.

Known
-----
- Balance is rough: this is a first pass and the numbers will follow how it plays.
- In co-op, Shock only raises the damage of the player who applied it.
- Map and enemies are the same as the stable version for now.
