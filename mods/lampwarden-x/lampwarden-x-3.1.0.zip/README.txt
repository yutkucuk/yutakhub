Lampwarden EXPERIMENTAL v3.1.0
==============================

This is the redesign of the game, as a test build. The stable version (2.5.1) stays in yutakhub as
"Lampwarden"; this one installs separately and keeps its own save.

What is in this build
---------------------
- One playable character: the RANGER. Sorceress, Monk and Witch come in later builds.
- The old weapons, items and perks are gone. Three things replace them:

  SKILLS     The Ranger has 8 skills and uses 4 at a time. They go off on their own.
             Every skill has tags (Lightning, Cold, Fire, Poison, Projectile, Area, Duration...).
  SUPPORT    Come from level-up cards and go into a skill. They change it: more arrows, forking,
  GEMS       chaining, a wider area, a second element... Each gem sits in one skill only.
             Move them around with the "SKILLS & GEMS" button in the shop.
  EQUIPMENT  10 slots: bow, quiver, helmet, body armour, gloves, boots, belt, amulet, 2 rings.
             Normal / Magic / Rare / Unique. Bought in the shop, dropped by chests.
             Spare pieces go to the bag (15 places). Click a bag piece to equip, right-click to sell.

New in 3.1.0
------------
- LOOT: enemies drop equipment, crafting currency and now and then a support gem. Walk over it to
  take it. Whatever is left when the wave ends comes to you. In co-op everyone sees their own loot.
- CRAFTING CURRENCY: Spark of Change, Spark of Growth, Kingmaker's Seal, Orb of Turmoil, Star of
  Ascension and the very rare Tear of the Beacon. Pick a piece in the inventory and apply one: add
  a bonus, raise the rarity, swap a bonus or roll all the values again.
- AFFIXES: every bonus has 5 tiers (T1-T5), each with its own range of values. Higher tiers turn
  up in later waves. A piece holds at most 3 prefixes and 3 suffixes.
- The VENDOR now sells support gems and currency too. The shop has three pages: Vendor, Inventory
  & Crafting, Skills & Gems.
- More gold, slightly softer enemy health.

Things that connect (to try)
----------------------------
- Storm Arrow + Storm Stakes: whenever your lightning strikes near a stake, the stake bursts.
- Venom Bloom + Ember Volley: fire sets the poison cloud off.
- Gale Shot: your arrows that fly through the twister split in two.
- "Infusion" gems add a second element to a skill. Frost Fan with Storm Infusion also sets off
  stakes and Shocks.
- Ailments: Shock (the enemy takes more damage from you), Chill/Freeze, Ignite, Poison.

Keys
----
WASD move, mouse aim, Q Tempest Call, SPACE dash, E place turret, R repair, TAB shop, F ready.

Known
-----
- Balance is rough: this is a first pass and the numbers will follow how it plays.
- In co-op, Shock only raises the damage of the player who applied it.
- Map and enemies are the same as the stable version for now.
