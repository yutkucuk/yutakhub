Lampwarden EXPERIMENTAL v3.16.1
==============================

This is the redesign of the game, as a test build. The stable version (2.5.1) stays in yutakhub as
"Lampwarden"; this one installs separately and keeps its own save.

What is in this build
---------------------
- Four playable characters: the RANGER, the BLOOD MAGE, the MONK and the WITCH.
- The old weapons, items and perks are gone. Three things replace them:

  SKILLS     Every character has 8 skills and uses 4 at a time. They go off on their own.
             Every skill has tags (Lightning, Cold, Fire, Melee, Area, Duration...).
  SUPPORT    Come from level-up cards and go into a skill. They change it: more arrows, forking,
  GEMS       chaining, a wider area, a second element... Each gem sits in one skill only.
             Move them around on the "SKILLS & GEMS" page of the shop.
  EQUIPMENT  6 slots: Weapon, Off-hand, Armour, Amulet, 2 Rings. Normal / Magic / Rare / Unique.
             Bought in the shop, dropped by chests. Spare pieces go to the bag (8 places).
             Hover a piece: [E] wear, [S] sell.

3.16.1: the Reroll button now sits right above the goods it rerolls ([R] still works).

New in 3.16.0: NEW DEFENCES, THE TEAR, A LORD WHO USES HIS SWORD, A HIVE MOTHER WHO IS A BEE
-----------------------------------------------------------------------------------------
- THE TURRETS ARE GONE (Lepetos stays). Twelve defences replace them, built from what a lampwarden
  has: Lantern Post, Thornhedge, Candle Ring, Rime Bell, Cinder Kiln, Ember Bellows, Storm Vane,
  Watchfire, Wayshrine, Ballista, Moth Cage, Beacon Mirror. Each has its own model, moving parts and
  sound. New mechanics: the Watchfire (enemies in its light take 18% more damage from everything, and
  the circle counts as lit, as does the ground round a Lantern Post), the Moth Cage (homing moths, one enemy each), the Kiln leaves burning ground,
  the Thornhedge hurts what leans on it, the Ballista pierces 3, the Bell tolls instead of humming,
  the Mirror takes its ray from the Beacon itself. Old saved runs are converted.
- THE TEAR OF THE BEACON is bright cyan, stands under an 18 m pillar of light with a light of its own,
  has its own (loud) sound, ducks the music, and is marked on the minimap. Drops now announce
  themselves by value: Rare a thin shaft, Unique a pillar and a light, the Tear above all.
- THE LORD OF THE DARK swings his sword: a wide arc is marked on the ground and fills for one second,
  then the blade goes through it. Walk or dash out; behind him is safe. Below half health a quicker
  backhand follows. THE HIVE MOTHER is redrawn as a bee.
- Fixed: after a boss charged, its attack list started over, so the attacks at the end never came.
- THE BREAKWATER: nothing there mentions generators any more. Blackout nights never come there; Sea
  Fog does (real fog on screen), and the Beacon's Wrath burns it off. The lamps relight after a wave.
- Reroll sits fixed in the top row of the shop, and [R] rerolls. A crosshair of its own for every
  character replaces the mouse pointer in play. The Great Light is now The Beacon's Wrath, on [X];
  its damage is no longer counted in your DPS. Time spent down: 5.9 s at wave 1, 4 s at wave 20
  (was 6.4 to 14 s).
- Not tested: how any of it sounds, how it moves, Windows, two real players.

New in 3.15.1: SMACKS, CRACKLE, TOUGHER ENEMIES
-----------------------------------------------
- Every melee hit is heard: six takes (three bright slaps, three dull punches), a slam under the big ones.
- Lightning crawls over what it hits, forks to what stands near (for show), and has new sounds.
- Enemy health: Easy 0.18 -> 0.24, Normal 0.58 -> 0.80, Hard 0.82 -> 1.25, Nightmare 1.25 -> 2.1.

New in 3.15.0: HIT FEEL, COMBOS, MUSIC FOR EACH MAP AND EACH CHARACTER
---------------------------------------------------------------------
- An enemy that is hit recoils along the blow and swells for an instant; sparks fly on in the
  direction of the hit; the body gives its own sound (thud, thock or pat, several takes each),
  a crack on a critical hit; the dead are thrown and tumble. Melee nudges the camera and the
  striking arm bites for a moment before it follows through.
- MONK: Staff Sweep is a chain of five ending in a somersault. The other three cycle gestures.
- Each map has its own arrangement, and the tune is played by the character's own instrument.

New in 3.14.1: THE WITCH'S OWN MOVEMENT, HOW SLEEP LOOKS, BALANCE
----------------------------------------------------------------
- Eleven clips of her own: idle, run, one gesture for each of her eight skills and for Good Night.
- A sleeper is lilac, slumped and breathing, not ice blue.
- Balance: sleep 1.6 -> 1.3 s, pops hit less, Good Night 18 -> 22 s, early skills down, Lullaby and Bad Dream up.

New in 3.14.0: THE FOURTH CHARACTER, THE WITCH
----------------------------------------------
A quiet caster: moths, spores, wind chimes, bubbles. Her sounds are whispers, wings and soft pops.
- HUSH: her skills lay Hush. At 4 an enemy falls asleep and she hits it 35% harder. Anything that
  dies hushed or asleep pops, hurting what is near and hushing it in turn; pops chain, and each
  one in a row sounds a step higher.
- 8 skills (Moth Lantern, Spore Bloom, Lullaby, Wind Chimes, Dew Bubbles, Bad Dream, The Hushed
  Hour, Veil of Moths), the ability Good Night, her own gear, 3 uniques, 2 passives, 1 support gem.

New in 3.13.0: CHARACTERS, ITEMS AND BUILDS GONE THROUGH AGAIN
--------------------------------------------------------------
All 24 skills were measured one by one (level 1 and 7, one tough target and a crowd of 24), then
as kits of four. What the numbers said: the lightning Ranger did twice what anyone else did, the
Monk hit a single target for a third of that, the Blood Mage sat in between.
- MONK up: Staff Sweep 14 -> 16.5, Frost Palm 72 -> 108, Spark Fists 9 -> 12.5, Gale Kick 30 -> 37,
  Resonant Gong 14 -> 19, Falling Sky 170 -> 205, Frost Image 14 -> 17. Each Ki held: 5% damage (was 4).
- BLOOD MAGE (the Sorceress's name from now on) up: Blood Lance 17 -> 20, Blood Nova 26 -> 34 and
  2.4 -> 2.2 s, Exsanguinate 80 -> 96, Leech Tendrils 7 -> 8.5, Blood Pool 7 -> 8, Crimson Moon 10 -> 11.5.
- RANGER: Frost Fan 16 -> 20, shards 75% -> 85%. Storm Stakes 14 -> 12.5, Storm Arrow's arcs 60% -> 55%.
- 6 NEW UNIQUES (24 in all): Warden's Tally, Moonwake, The Long Thirst, Ashen Heart, Mantle of the
  Iron Lotus, Stormcaller's Wraps.
- NEW AFFIX on weapons: "+1 to the level of Physical skills" (rare).
- Item and gem texts fit every class now ("shots", not "arrows"). Hunter's Jerkin is Padded Jerkin.

New in 3.12.0: THE CROSSROADS AND THE PASS, REBUILT
---------------------------------------------------
The two old maps were rebuilt to the standard of the Breakwater. What you play on is the same
size (roads, generators, lamps, gates); the world it stands in is new.
- THE CROSSROADS is a village at night: cobbled roads, a square with a compass rose, and four
  places in the four corners: the MILL (its sails turn) and two houses, the WHEAT FIELD and the
  kitchen garden, the POND (rings on the water, reeds, fireflies), the BURIAL GROUND.
- THE PASS is a mountain road in the snow. Snow falls. A WATERFALL comes down the rock wall, the
  beck goes under the road and over the edge. Below the drop a slow SEA OF CLOUD. The road comes
  in over a TIMBER BRIDGE in the west and goes into a TUNNEL in the east.
- Wind you can see: tree tops, reeds, wheat, washing and pennants move.
- Every map has its own ambience.
- FIX: an enemy caught between two posts of a fence, or between a house and the barrel beside it
  (the wave never ended). Going round obstacles was reworked and tested for every enemy kind.

New in 3.11.0: NEW SOUND, NEW MUSIC, ONE THEME, A NEW MENU
----------------------------------------------------------
- EVERY SOUND EFFECT IS NEW (114 of them): real instrument samples mixed with air, impact, water
  and fire built in code. Frequent sounds are small, soft and come in several takes; rare ones are
  big. Levels are set by kind of sound and a limiter sits on the output.
- Gems and blood orbs picked up in a row climb a scale.
- THE MUSIC IS REWRITTEN: one piece in three layers (D minor). The night watch always plays; drums
  and pulsing strings join when a wave is on; brass, voices and piano when a boss is here or the
  Beacon is failing. The music steps back for a moment under a big sound.
- ONE THEME: ink-dark panels, brass frames, parchment text, the Beacon's amber. A carved capital
  face (Cinzel) for titles, Alegreya Sans for everything that is read.
- A NEW MAIN MENU: a list instead of tiles, and the hero you pick stands there alive.

New in 3.10.0: NEW MODELS, JOINTED ANIMATION, THE GREAT LIGHT
-------------------------------------------------------------
(The first part of the big overhaul. Sound, music, the theme, the menu and the two older maps follow.)

- THE HEROES ARE REDRAWN and jointed: body, head, arms, legs, hair, cape, skirt, bow and staff are
  separate parts posed every frame, instead of four swapped frames. Running, standing, dashing,
  going down and every skill have their own movement.
- THE MONK'S LEAP (Q) is a real jump now, and lightning strikes where he lands.
- BLOWS LAND ON TIME: the Monk's sweep, palm and kick deal their damage when the movement connects.
  Heavy hits hold the screen for an instant (solo only).
- ALL 17 ENEMIES ARE REDRAWN, bosses included. Their parts move separately, and they swell white
  and vanish when they die.
- THE BREAKWATER HAS NO GENERATORS BUT THE GREAT LIGHT: the lighthouse charges during a wave (kills
  speed it up). When it is full, [G] sends a wall of light down the quay: damage, burn, slow and
  knockback for everything it passes. In Blackout it also relights the lamps for 40 seconds.

New in 3.9.0: THE BREAKWATER (a new map)
----------------------------------------
A one-sided map. Main menu > Solo (or the host in co-op) > Map: THE BREAKWATER.

- The Beacon is the lighthouse at the tip of a stone pier. Water on three sides; the only way in
  is the wide quay from the town gate to the lighthouse (about 30 m wide, 58 m long).
- THREE ARCHES: the town gate has three arches. Early waves come through one, then two, and from
  wave 6 through all three. Between waves the arches that will open are marked.
- Nothing behind you: the round head of the pier behind the Beacon is closed.
- LIGHT: posts on both kerbs, double standards beside the rails, two lanterns on the gate. With
  the generators running every place you can walk is lit.
- ON THE QUAY: three things to fight round (cargo, the capstan, a tipped cart) and the buffer at
  the end of the rails. Along the edges: crates, barrels, a net rack, a hand crane, an upturned boat.
- THE SEA: its own surface, with lines of swell, foam against the wall and glints where a light
  lies on it. Five moored boats that ride the swell, three channel buoys that flash in turn.
- THE TOWN GATE: a battlemented wall, three arches with their portcullises drawn up, a round
  tower on each side, roofs behind it and a sick green glow coming through.
- The minimap, the enemy-path markers and the ring of light follow this map's shape.
- A quiet loop of sea plays on this map.
- New achievement: Harbour Light (win a run on The Breakwater).
- The other two maps are unchanged.

New in 3.8.0: THE MONK
----------------------
The third character. He fights with a staff and bare hands, right next to the enemy; none of
his skills reach far.

- KI: his blows build Ki (up to 5; shown as dots next to the life bar and as lights circling
  him). Every point he holds: 4% more damage, 2% attack speed, 4% less damage taken. Every point
  he GAINS heals 2% of his life (also when Ki is full). Ki starts to fade after 5 seconds
  without a blow.
- HE STANDS IN THE WAY: enemies notice the Monk from 12 m instead of 9 and come for him instead
  of the Beacon.
- NO SWINGS AT AIR: a melee skill goes off only when something is within reach, and turns to
  the nearest enemy if nothing stands where you aim.
- 8 SKILLS
    Staff Sweep     the starter. A wide arc; every third swing is heavy: wider, harder, throws
                    enemies back, gives 1 Ki
    Frost Palm      one blow at the TOUGHEST enemy in reach; a kill shatters it, the shards hit
                    everything around, 1 Ki
    Spark Fists     four quick blows that arc on and Shock; 1 Ki if all four land
    Gale Kick       hits everything around you and throws it back; 1 Ki for 3 or more
    Resonant Gong   set at the cursor; whenever a melee blow of yours lands within its hearing
                    it rings and sends out a wave of THE SAME KIND as the blow
    Falling Sky     goes off BY ITSELF when Ki is full: spends all of it, a thunderbolt comes down
    Frost Image     an image of ice steps into the fight and strikes around itself; its blows
                    ring the Gong too
    Still Breath    2 Ki and life at once; much harder to hit for 4 seconds
- ABILITY (Q) DRAGON'S LEAP: leap to the cursor (up to 12 m), the ground breaks where you land,
  Ki is filled. This is how you get to Spitters and Lobbers that stand far off.
- 3 NEW SUPPORT GEMS (melee skills only): Flowing Strikes (half again as much Ki), Aftershock
  (30% of a hit goes on to the two nearest enemies), Momentum (3% more damage per Ki).
- EQUIPMENT: four staves, and Prayer Beads, Hand Wraps and a Pilgrim's Sash for the off-hand.
  New bonuses: melee damage, Ki from your blows. Three uniques: Skybreaker (Falling Sky strikes
  twice), Beads of the Quiet Hour (keep 2 Ki after Falling Sky), The Sixth Knot (hold one more).
- His own model, 20 new icons, 15 new sounds, and a crescent trail where a swing went.

New in 3.7.0: SIMPLER
---------------------
- EQUIPMENT: 6 slots instead of 10 (Weapon, Off-hand, Armour, Amulet, two Rings). The bag holds
  8 instead of 15. A piece carries at most 4 bonuses, and bonuses are stronger to match.
- CURRENCY: 4 kinds instead of 10, one rule each:
    Spark of Making     adds a new bonus (rarity rises by itself)
    Orb of Turmoil      replaces the bonus YOU PICKED with a new one
    Eclipse Shard       a gamble: seals the piece, one of four things happens
    Tear of the Beacon  raises the bonus YOU PICKED to the best tier (T1); the rarest drop
  Click a bonus on the bench to pick it. A changed bonus says "NEW" or "was: ...", a removed
  one is listed in red underneath.
- TIERS are read by colour: gold T1, blue T2, green T3, white T4, grey T5. Point at a bonus for
  its tier and that tier's range.
- A BONUS YOU CAN'T USE is dimmed and says so (cold damage with no cold skill, for one).
- ESTIMATED EFFECT: the comparison has one line such as "damage ▲ +8%"; pieces in the bag carry
  a ▲ / ▼ mark. Point at a piece and press [E] to wear it or [S] to sell it; one button
  sells every piece marked ▼.
- The vendor shows 5 offers instead of 7; equipment offers list their bonuses one by one.
- SORCERESS: the Transfusion gem is gone. A spell she can't pay for no longer goes off.
  Overflow, orb healing, Leech Tendrils and Vampiric are weaker.
- Long descriptions fit the level-up cards. Rare piece names read better.
- Runs saved by an older build can't be continued (the equipment layout changed).

New in 3.6.0
------------
- CONTINUE WHERE YOU LEFT OFF: a solo run is saved by itself between waves. Main menu > Solo >
  "CONTINUE" at the top. Leave in the middle of a wave and you come back to the preparation
  before it, with what you bought and built. The save is removed when the run ends. Co-op runs
  are not saved.
- THE COMPARISON was rewritten without the table: "This piece gives", "You gain" and "You lose".
  A bonus both pieces have reads "lightning damage: +25% → +24%", old to new.

New in 3.5.0
------------
- SKILLS & GEMS is a page of the shop now and fits the screen: skills with their four sockets on
  the left, loose gems on the right (they scroll down instead of growing sideways). Point at a gem
  to read what it does, which of your skills it fits, and to socket it with one click.
- THE COMPARISON is a table: one row per bonus with the value on offer, the value you wear and
  the difference. It fits without scrolling. The inventory shows the same table for bag pieces.
- THE BENCH: currencies are small tiles with their counts; the ones you can use are lit.
- Turret names are no longer cut off. Level-up cards and the vendor say which of your skills a
  support gem fits.
- TURKISH LETTERS in headings no longer come out bolder than the rest.

New in 3.4.0
------------
- SECOND CHARACTER: the SORCERESS, a blood mage. Pick her in the main menu.
  * Her skills cost a share of her life (a cast never takes the last point).
  * Enemies she kills leave BLOOD ORBS. An orb heals; life above full becomes OVERFLOW, which
    takes damage first, fades when it is not fed and makes blood skills hit harder while it lasts.
  * 8 skills: Blood Lance, Blood Pool, Blood Nova, Leech Tendrils, Boiling Blood, Crimson Moon,
    Exsanguinate, Blood Rite. Ability [Q]: Crimson Tide.
  * How they connect: in your Pool casts are free and the Nova is wider; the Nova bursts the orbs
    on the ground for more damage; the Moon drips orbs and strengthens lances that fly through
    it; what dies boiling bursts and leaves an orb; Exsanguinate hits harder the lower your life;
    the Rite makes everything free for a while.
  * Her own weapons and off-hands, blood affixes, 3 uniques, 3 new support gems (Blood Price,
    Transfusion, Vampiric) and 4 blood passives.
- Swiftness, Heavy Hand, the Infusions, Culling and Precision now fit every skill.
- Equipment drops are for the character you play (bows for the Ranger, staves for the Sorceress).

New in 3.3.0
------------
- VISUAL EFFECTS: poison clouds, explosions, stakes, twisters, frost and fire are round and soft
  now; the square plates are gone. Loot sits in a round glow over a turning ring.
- COLLISION: lamp posts, trees, fences and generators are solid. You don't bump into your own
  turrets. Big enemies push through the small ones and no longer wait in front of a turret; a row
  of turrets in their way gets attacked.
- Currency and gems that fall outside the yard slide to where you can reach them.
- VENDOR: what you wear is always in view. Point at a piece and it is shown next to yours, with
  what you would gain and lose by swapping.
- DPS: live DPS at the top left during a wave; in the shop, last wave's average and peak, the
  change from the wave before and which skill the damage came from.
- RANGER: the Chain, Fork and Pierce gems fitted no skill at all; fixed. Gale Shot now goes to the
  cursor and stays there. Frost Fan and Longshot are stronger.

New in 3.2.0
------------
- TIERS now read the way the genre does: T1 is the best, T5 the lowest. Good tiers can only turn up
  in later waves (T4: wave 4, T3: 8, T2: 12, T1: 16) and stay rare when they can.
- EQUIPMENT no longer drops on the ground; it only comes out of CHESTS. Elites and bosses always
  leave one, other enemies leave a small one now and then. Unopened chests open by themselves
  when the wave ends. Only currency and support gems lie on the ground.
- FOUR NEW VALUABLE CURRENCIES: Ash of Unmaking (removes a bonus), Eclipse Shard (an unpredictable
  change, then the piece is sealed), Crown Star (adds a T1 bonus), Twin Flame (copies a piece;
  the rarest, with its own sound and banner).

New in 3.1.0
------------
- LOOT: enemies drop equipment, crafting currency and now and then a support gem. Walk over it to
  take it. Whatever is left when the wave ends comes to you. In co-op everyone sees their own loot.
- CRAFTING CURRENCY: Spark of Change, Spark of Growth, Kingmaker's Seal, Orb of Turmoil, Star of
  Ascension and the very rare Tear of the Beacon. Pick a piece in the inventory and apply one: add
  a bonus, raise the rarity, swap a bonus or roll all the values again.
- AFFIXES: every bonus has 5 tiers (T1-T5), each with its own range of values. Higher tiers turn
  up in later waves. A piece holds at most 3 prefixes and 3 suffixes.
- The VENDOR now sells support gems and currency too. The shop has three pages: Vendor, Inventory
  & Crafting, Skills & Gems.
- More gold, slightly softer enemy health.

Things that connect (to try)
----------------------------
- Storm Arrow + Storm Stakes: whenever your lightning strikes near a stake, the stake bursts.
- Venom Bloom + Ember Volley: fire sets the poison cloud off.
- Gale Shot: your arrows that fly through the twister split in two.
- "Infusion" gems add a second element to a skill. Frost Fan with Storm Infusion also sets off
  stakes and Shocks.
- Ailments: Shock (the enemy takes more damage from you), Chill/Freeze, Ignite, Poison.

Keys
----
WASD move, mouse aim, Q character ability, SPACE dash, E build a defence, R repair (in the shop: reroll),
X the Beacon's Wrath (Breakwater), TAB shop, F ready.

Known
-----
- Balance is rough: this is a first pass and the numbers will follow how it plays.
- In co-op, Shock only raises the damage of the player who applied it.
- Map and enemies are the same as the stable version for now.
