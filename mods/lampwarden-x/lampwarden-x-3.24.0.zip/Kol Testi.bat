@echo off
rem Lampwarden kol testi: oyunu --padlog ile acar. 30 saniye sonra kendi kapanir,
rem gordugu her seyi bu klasordeki gamepad_log.txt dosyasina yazar.
start "" "%~dp0Lampwarden.exe" --padlog
