extends Node2D
## Ring and name tag that mark a player in the world, or the grave of a fallen player.

var label: String = ""
var simple: bool = false
var grave: bool = false
var ring_color: Color = Color(0.35, 0.65, 1.0)
var _down: bool = false
var _progress: float = 0.0


func _ready() -> void:
	z_index = -1
	if label.is_empty():
		return
	var l: Label = Label.new()
	l.text = label
	if ResourceLoader.exists("res://UI/Fonts/EBGaramond-Regular.ttf"):
		l.add_theme_font_override("font", load("res://UI/Fonts/EBGaramond-Regular.ttf"))
	l.add_theme_font_size_override("font_size", 11)
	l.add_theme_color_override("font_color", ring_color)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 3)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.size = Vector2(140, 14)
	l.position = Vector2(-70, -40 if grave else -66)
	l.z_index = 20
	add_child(l)


func set_state(down: bool, progress: float) -> void:
	if down != _down or absf(progress - _progress) > 0.005:
		_down = down
		_progress = progress
		queue_redraw()


func _draw() -> void:
	var c: Color = Color(0.9, 0.2, 0.15) if (_down or grave) else ring_color
	draw_arc(Vector2.ZERO, 13.0, 0.0, TAU, 32, Color(0, 0, 0, 0.5), 3.0)
	draw_arc(Vector2.ZERO, 13.0, 0.0, TAU, 32, c, 1.5)
	if _progress > 0.0:
		draw_arc(Vector2.ZERO, 19.0, -PI * 0.5, -PI * 0.5 + TAU * clampf(_progress, 0.0, 1.0), 40, Color(1.0, 0.85, 0.3), 3.0)
	if grave:
		var stone: Color = Color(0.62, 0.6, 0.58)
		draw_rect(Rect2(-2.5, -22, 5, 22), Color(0, 0, 0, 0.7))
		draw_rect(Rect2(-8.5, -17, 17, 5), Color(0, 0, 0, 0.7))
		draw_rect(Rect2(-1.5, -21, 3, 20), stone)
		draw_rect(Rect2(-7.5, -16, 15, 3), stone)
	if simple:
		draw_circle(Vector2(0, -14), 7.0, c)
		draw_rect(Rect2(-6, -8, 12, 14), c)
