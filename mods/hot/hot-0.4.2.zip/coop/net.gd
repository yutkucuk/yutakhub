extends Node
## Steam lobby + P2P transport. Exactly two players: the lobby owner is the host.

signal peer_connected
signal peer_disconnected
signal message(msg: Array)
signal status_changed

const CHANNEL: int = 0
const SEND_UNRELIABLE: int = 0
const SEND_RELIABLE: int = 2
const M_HELLO: int = 1
const M_PING: int = 17
const M_BYE: int = 19
const TIMEOUT: float = 12.0

var coop: Node
var steam: Object = null
var my_id: int = 0
var my_name: String = "Player"
var lobby_id: int = 0
var peer_id: int = 0
var peer_name: String = "Partner"
var is_host: bool = false
var connected: bool = false
var creating: bool = false
var last_error: String = ""
var ping_ms: int = 0
var peer_game_version: String = ""
var last_lobby: int = 0
const LAST_LOBBY_FILE: String = "user://coop_last_lobby.txt"
var _silence: float = 0.0
var _tick: float = 0.0
var _auto_invite: bool = false


func _ready() -> void:
	coop = get_parent()
	if not Engine.has_singleton("Steam"):
		last_error = "Steam is not available"
		coop.info("Steam singleton missing - co-op disabled")
		return
	steam = Engine.get_singleton("Steam")
	_bind("lobby_created")
	_bind("lobby_joined")
	_bind("join_requested")
	_bind("lobby_chat_update")
	_bind("p2p_session_request")
	_bind("p2p_session_connect_fail")
	await get_tree().process_frame
	my_id = int(steam.getSteamID())
	my_name = str(steam.getPersonaName())
	if steam.has_method("allowP2PPacketRelay"):
		steam.allowP2PPacketRelay(true)
	coop.info("Steam ready: %s (%d)" % [my_name, my_id])
	if FileAccess.file_exists(LAST_LOBBY_FILE):
		last_lobby = int(FileAccess.get_file_as_string(LAST_LOBBY_FILE))
	_check_launch_args()


# Connects a Steam signal whatever its argument count is, so a different GodotSteam build cannot break us.
func _bind(sig: String) -> void:
	var count: int = -1
	for s in steam.get_signal_list():
		if s["name"] == sig:
			count = s["args"].size()
			break
	match count:
		0: steam.connect(sig, _s0.bind(sig))
		1: steam.connect(sig, _s1.bind(sig))
		2: steam.connect(sig, _s2.bind(sig))
		3: steam.connect(sig, _s3.bind(sig))
		4: steam.connect(sig, _s4.bind(sig))
		5: steam.connect(sig, _s5.bind(sig))
		_: coop.info("Steam signal not found: %s" % sig)

func _s0(sig: String) -> void: _on_steam(sig, [])
func _s1(a, sig: String) -> void: _on_steam(sig, [a])
func _s2(a, b, sig: String) -> void: _on_steam(sig, [a, b])
func _s3(a, b, c, sig: String) -> void: _on_steam(sig, [a, b, c])
func _s4(a, b, c, d, sig: String) -> void: _on_steam(sig, [a, b, c, d])
func _s5(a, b, c, d, e, sig: String) -> void: _on_steam(sig, [a, b, c, d, e])


func _on_steam(sig: String, args: Array) -> void:
	match sig:
		"lobby_created":
			creating = false
			if args.size() >= 2 and int(args[0]) == 1:
				lobby_id = int(args[1])
				is_host = true
				steam.setLobbyData(lobby_id, "mod", "hotcoop")
				steam.setLobbyData(lobby_id, "ver", coop.VERSION)
				steam.setLobbyJoinable(lobby_id, true)
				steam.setRichPresence("connect", "+connect_lobby %d" % lobby_id)
				coop.info("Lobby created: %d" % lobby_id)
				if _auto_invite:
					_auto_invite = false
					invite()
			else:
				last_error = "Could not create lobby"
				coop.info("Lobby creation failed: %s" % str(args))
			status_changed.emit()
		"lobby_joined":
			# (lobby_id, permissions, locked, response); response 1 = success
			if args.size() >= 4 and int(args[3]) != 1:
				last_error = "Could not join the lobby. It may be closed."
				_remember_lobby(0)
				coop.info(last_error)
				status_changed.emit()
				return
			var joined: int = int(args[0])
			if lobby_id != 0 and lobby_id != joined:
				return
			lobby_id = joined
			is_host = int(steam.getLobbyOwner(lobby_id)) == my_id
			coop.info("Joined lobby %d (host=%s)" % [lobby_id, str(is_host)])
			_remember_lobby(lobby_id)
			_find_peer()
			status_changed.emit()
		"join_requested":
			# The player accepted an invite or pressed "Join Game" in the friends list.
			if args.size() >= 1:
				join(int(args[0]))
		"lobby_chat_update":
			_find_peer()
		"p2p_session_request":
			if args.size() >= 1 and _is_lobby_member(int(args[0])):
				steam.acceptP2PSessionWithUser(int(args[0]))
		"p2p_session_connect_fail":
			coop.info("P2P connect fail: %s" % str(args))


func _check_launch_args() -> void:
	var args: Array = Array(OS.get_cmdline_args())
	if steam.has_method("getLaunchCommandLine"):
		args.append_array(str(steam.getLaunchCommandLine()).split(" ", false))
	for i in args.size():
		if str(args[i]) == "+connect_lobby" and i + 1 < args.size():
			join(int(str(args[i + 1])))
			return


func host(open_invite: bool = true) -> void:
	if steam == null or lobby_id != 0 or creating:
		if lobby_id != 0 and open_invite:
			invite()
		return
	creating = true
	last_error = ""
	_auto_invite = open_invite
	steam.createLobby(1, 2)  # friends only, two players
	status_changed.emit()


func invite() -> void:
	if steam and lobby_id != 0:
		steam.activateGameOverlayInviteDialog(lobby_id)


func join(target_lobby: int) -> void:
	if steam == null or target_lobby == 0 or target_lobby == lobby_id:
		return
	if lobby_id != 0:
		leave()
	last_error = ""
	coop.info("Joining lobby %d" % target_lobby)
	steam.joinLobby(target_lobby)


func _remember_lobby(id: int) -> void:
	last_lobby = id
	var f: FileAccess = FileAccess.open(LAST_LOBBY_FILE, FileAccess.WRITE)
	if f:
		f.store_string(str(id))


func rejoin() -> void:
	if last_lobby != 0 and lobby_id == 0:
		join(last_lobby)


func leave() -> void:
	if steam == null:
		return
	_remember_lobby(0)
	if connected:
		send([M_BYE])
	if lobby_id != 0:
		steam.leaveLobby(lobby_id)
		steam.setRichPresence("connect", "")
	if peer_id != 0:
		steam.closeP2PSessionWithUser.call_deferred(peer_id)
	var was_connected: bool = connected
	lobby_id = 0
	peer_id = 0
	is_host = false
	connected = false
	creating = false
	if was_connected:
		peer_disconnected.emit()
	status_changed.emit()


func _is_lobby_member(id: int) -> bool:
	if lobby_id == 0:
		return false
	for i in int(steam.getNumLobbyMembers(lobby_id)):
		if int(steam.getLobbyMemberByIndex(lobby_id, i)) == id:
			return true
	return false


func _find_peer() -> void:
	if lobby_id == 0:
		return
	var found: int = 0
	for i in int(steam.getNumLobbyMembers(lobby_id)):
		var m: int = int(steam.getLobbyMemberByIndex(lobby_id, i))
		if m != my_id and m != 0:
			found = m
			break
	if found == peer_id:
		return
	if found == 0:
		_drop_peer("left the lobby")
		return
	peer_id = found
	peer_name = str(steam.getFriendPersonaName(peer_id))
	is_host = int(steam.getLobbyOwner(lobby_id)) == my_id
	_silence = 0.0
	coop.info("Peer found: %s (%d)" % [peer_name, peer_id])
	status_changed.emit()


func _drop_peer(reason: String) -> void:
	if peer_id == 0:
		return
	coop.info("Peer lost: %s" % reason)
	steam.closeP2PSessionWithUser(peer_id)
	peer_id = 0
	if connected:
		connected = false
		peer_disconnected.emit()
	if lobby_id != 0:
		is_host = int(steam.getLobbyOwner(lobby_id)) == my_id
	status_changed.emit()


func send(msg: Array, reliable: bool = true) -> void:
	if steam == null or peer_id == 0:
		return
	steam.sendP2PPacket(peer_id, var_to_bytes(msg), SEND_RELIABLE if reliable else SEND_UNRELIABLE, CHANNEL)


func _process(delta: float) -> void:
	if steam == null or lobby_id == 0:
		return
	_read_packets()
	_tick += delta
	if _tick >= 1.0:
		_tick = 0.0
		_find_peer()
		if peer_id != 0:
			if not connected:
				send([M_HELLO, coop.PROTO, coop.VERSION, my_name, false, coop.game_version()])
			else:
				send([M_PING, Time.get_ticks_msec(), false])
	if peer_id != 0 and connected:
		_silence += delta
		if _silence > TIMEOUT:
			_drop_peer("timeout")


func _read_packets() -> void:
	for _i in 512:
		var size: int = int(steam.getAvailableP2PPacketSize(CHANNEL))
		if size <= 0:
			return
		var pkt = steam.readP2PPacket(size, CHANNEL)
		if not (pkt is Dictionary) or pkt.is_empty():
			return
		var sender: int = int(pkt.get("steam_id_remote", pkt.get("remote_steam_id", 0)))
		if sender == 0 or sender != peer_id:
			if peer_id == 0:
				_find_peer()
			if sender != peer_id:
				continue
		var data = pkt.get("data")
		if not (data is PackedByteArray) or data.is_empty():
			continue
		var msg = bytes_to_var(data)
		if not (msg is Array) or msg.is_empty() or not (msg[0] is int):
			continue
		_silence = 0.0
		_handle(msg)


func _handle(msg: Array) -> void:
	match int(msg[0]):
		M_HELLO:
			if msg.size() < 5:
				return
			if int(msg[1]) != coop.PROTO:
				last_error = "Version mismatch: you %s, partner %s" % [coop.VERSION, str(msg[2])]
				coop.info(last_error)
				status_changed.emit()
				return
			peer_name = str(msg[3])
			peer_game_version = str(msg[5]) if msg.size() > 5 else ""
			if not peer_game_version.is_empty() and peer_game_version != coop.game_version():
				coop.info("Game versions differ: mine %s, partner %s" % [coop.game_version(), peer_game_version])
			if not bool(msg[4]):
				send([M_HELLO, coop.PROTO, coop.VERSION, my_name, true, coop.game_version()])
			if not connected:
				connected = true
				last_error = ""
				coop.info("Connected to %s" % peer_name)
				peer_connected.emit()
				status_changed.emit()
		M_PING:
			if msg.size() >= 3:
				if bool(msg[2]):
					ping_ms = maxi(0, Time.get_ticks_msec() - int(msg[1]))
				else:
					send([M_PING, msg[1], true], false)
		M_BYE:
			_drop_peer("partner left")
		_:
			if connected:
				message.emit(msg)
