extends Node
## Shows the partner's projectiles and summons. Purely cosmetic: the owner sends what its objects look
## like and where they are, the other side draws plain sprites. No game logic runs on the copies.

const MAX_TRACKED: int = 60

var session: Node
var net: Node
var _pending: Array = []
var _tracked: Dictionary = {}    # id -> {"node", "vis"}
var _ghosts: Dictionary = {}     # id -> {"node", "pos", "rot", "age"}
var _next_id: int = 1
var _t: float = 0.0
var _res_cache: Dictionary = {}


func setup(p_session: Node) -> void:
	session = p_session
	net = p_session.net


func clear() -> void:
	_pending.clear()
	_tracked.clear()
	for id in _ghosts.keys():
		var g = _ghosts[id]["node"]
		if is_instance_valid(g):
			g.queue_free()
	_ghosts.clear()


func on_world_child(node: Node) -> void:
	if _tracked.size() + _pending.size() < MAX_TRACKED * 2:
		_pending.append(node)


func tick(delta: float) -> void:
	_age_ghosts(delta)
	if not session.partner_in_run:
		_pending.clear()
		return
	# objects added last frame now know who fired them
	if not _pending.is_empty():
		var batch: Array = _pending
		_pending = []
		for node in batch:
			if _tracked.size() >= MAX_TRACKED:
				break
			if not is_instance_valid(node) or not node.is_inside_tree() or node.is_queued_for_deletion():
				continue
			if not _is_mine(node):
				continue
			var vis: Node = _find_visual(node, 0)
			if vis == null:
				continue
			var msg: Array = _describe(vis)
			if msg.is_empty():
				continue
			var id: int = _next_id
			_next_id += 1
			_tracked[id] = {"node": node, "vis": vis}
			msg[1] = id
			net.send(msg)
	_t += delta
	if _t < 0.1:
		return
	_t = 0.0
	var ended: PackedInt32Array = PackedInt32Array()
	var ids: PackedInt32Array = PackedInt32Array()
	var data: PackedFloat32Array = PackedFloat32Array()
	for id in _tracked.keys():
		var vis = _tracked[id]["vis"]
		var node = _tracked[id]["node"]
		if not is_instance_valid(node) or not is_instance_valid(vis) or not vis.is_inside_tree() or node.is_queued_for_deletion():
			_tracked.erase(id)
			ended.append(id)
			continue
		ids.append(id)
		data.append(vis.global_position.x)
		data.append(vis.global_position.y)
		data.append(vis.global_rotation)
		if ids.size() >= 60:
			net.send([session.M_FX_POS, ids, data], false)
			ids = PackedInt32Array()
			data = PackedFloat32Array()
	if not ids.is_empty():
		net.send([session.M_FX_POS, ids, data], false)
	if not ended.is_empty():
		net.send([session.M_FX_END, ended])


func _is_mine(node: Node) -> bool:
	if node == session.player or node == session.puppet or node.has_meta("coop_id"):
		return false
	if not node.has_method("get_rootSourceGameObject"):
		return false
	return node.get_rootSourceGameObject() == session.player


func _find_visual(node: Node, depth: int) -> Node:
	for c in node.get_children():
		if c is AnimatedSprite2D and c.visible and c.sprite_frames != null and _plain_path(c.sprite_frames.resource_path):
			return c
		if c is Sprite2D and c.visible and c.texture != null and _plain_path(c.texture.resource_path):
			return c
	if depth < 3:
		for c in node.get_children():
			var found: Node = _find_visual(c, depth + 1)
			if found != null:
				return found
	return null


func _plain_path(path: String) -> bool:
	return not path.is_empty() and not path.contains("::")


func _describe(vis: Node) -> Array:
	var shader_path: String = ""
	var blend: int = -1
	var mat = vis.material
	if mat is ShaderMaterial and mat.shader != null and _plain_path(mat.shader.resource_path):
		shader_path = mat.shader.resource_path
	elif mat is CanvasItemMaterial:
		blend = mat.blend_mode
	var kind: int = 0
	var res: String = ""
	var extra: Array = []
	if vis is AnimatedSprite2D:
		res = vis.sprite_frames.resource_path
		extra = [str(vis.animation), vis.flip_h]
	else:
		kind = 1
		res = vis.texture.resource_path
		extra = [vis.hframes, vis.vframes, vis.frame, vis.flip_h]
	var p: Vector2 = vis.global_position
	var s: Vector2 = vis.global_scale
	return [session.M_FX_SPAWN, 0, kind, res, shader_path, blend, p.x, p.y, vis.global_rotation, s.x, s.y,
		vis.offset.x, vis.offset.y, vis.centered, vis.z_index, vis.modulate.to_html(), extra]


# ---------------------------------------------------------------- receiving side

func _res(path: String):
	if _res_cache.has(path):
		return _res_cache[path]
	var r = load(path) if ResourceLoader.exists(path) else null
	_res_cache[path] = r
	return r


func on_spawn(msg: Array) -> void:
	if msg.size() < 17 or session.world == null or _ghosts.size() >= MAX_TRACKED * 2:
		return
	var res = _res(str(msg[3]))
	if res == null or not (msg[16] is Array):
		return
	var extra: Array = msg[16]
	var node: Node2D = null
	if int(msg[2]) == 0 and res is SpriteFrames and extra.size() >= 2:
		var a: AnimatedSprite2D = AnimatedSprite2D.new()
		a.sprite_frames = res
		if res.has_animation(str(extra[0])):
			a.play(str(extra[0]))
		a.flip_h = bool(extra[1])
		a.offset = Vector2(msg[11], msg[12])
		a.centered = bool(msg[13])
		node = a
	elif int(msg[2]) == 1 and res is Texture2D and extra.size() >= 4:
		var sp: Sprite2D = Sprite2D.new()
		sp.texture = res
		sp.hframes = maxi(1, int(extra[0]))
		sp.vframes = maxi(1, int(extra[1]))
		sp.frame = clampi(int(extra[2]), 0, sp.hframes * sp.vframes - 1)
		sp.flip_h = bool(extra[3])
		sp.offset = Vector2(msg[11], msg[12])
		sp.centered = bool(msg[13])
		node = sp
	if node == null:
		return
	var shader = _res(str(msg[4])) if not str(msg[4]).is_empty() else null
	if shader is Shader:
		var sm: ShaderMaterial = ShaderMaterial.new()
		sm.shader = shader
		node.material = sm
	elif int(msg[5]) >= 0:
		var cm: CanvasItemMaterial = CanvasItemMaterial.new()
		cm.blend_mode = clampi(int(msg[5]), 0, 4)
		node.material = cm
	node.z_index = clampi(int(msg[14]), -100, 100)
	node.modulate = Color.from_string(str(msg[15]), Color.WHITE)
	session.world.add_child(node)
	var pos: Vector2 = Vector2(msg[6], msg[7])
	node.global_position = pos
	node.global_rotation = float(msg[8])
	node.global_scale = Vector2(msg[9], msg[10])
	_ghosts[int(msg[1])] = {"node": node, "pos": pos, "rot": float(msg[8]), "age": 0.0}


func on_pos(ids: PackedInt32Array, data: PackedFloat32Array) -> void:
	for i in ids.size():
		if i * 3 + 2 >= data.size():
			return
		var g = _ghosts.get(ids[i])
		if g != null:
			g["pos"] = Vector2(data[i * 3], data[i * 3 + 1])
			g["rot"] = data[i * 3 + 2]
			g["age"] = 0.0


func on_end(ids: PackedInt32Array) -> void:
	for id in ids:
		_remove(id)


func _remove(id: int) -> void:
	var g = _ghosts.get(id)
	if g != null:
		if is_instance_valid(g["node"]):
			g["node"].queue_free()
		_ghosts.erase(id)


func _age_ghosts(delta: float) -> void:
	for id in _ghosts.keys():
		var g: Dictionary = _ghosts[id]
		var node = g["node"]
		g["age"] += delta
		if not is_instance_valid(node) or g["age"] > 2.5:
			_remove(id)
			continue
		node.global_position = node.global_position.lerp(g["pos"], minf(1.0, delta * 14.0))
		node.global_rotation = lerp_angle(node.global_rotation, g["rot"], minf(1.0, delta * 14.0))
