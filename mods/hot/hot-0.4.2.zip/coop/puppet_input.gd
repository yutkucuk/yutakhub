extends Node
## Stands in for the game's PlayerInput on the partner's puppet: same lookups, values come from the network.

signal input_dir_changed(dir_vector: Vector2)
signal AutoAimChanged(autoAim: bool)
signal AutoAttackChanged(autoAttack: bool)

var walk: Vector2 = Vector2.ZERO
var aim: Vector2 = Vector2.DOWN
var _last_walk: Vector2 = Vector2.ZERO


func _process(_delta: float) -> void:
	if walk != _last_walk:
		_last_walk = walk
		input_dir_changed.emit(walk)


func get_inputWalkDir() -> Vector2:
	return walk


func get_aimDirection() -> Vector2:
	return aim if aim != Vector2.ZERO else Vector2.DOWN


func get_facingDirection() -> Vector2:
	return get_aimDirection()
