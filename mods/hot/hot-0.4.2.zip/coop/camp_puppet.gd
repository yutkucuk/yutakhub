extends Node2D
## The partner at the camp: a separate, look-only copy of their hero. The real camp heroes are never
## touched, so both players can pick any hero, including the same one.

const NAMES8: Array = ["E", "SE", "S", "SW", "W", "NW", "N", "NE"]
const MIRROR: Dictionary = {"E": "W", "W": "E", "SE": "SW", "SW": "SE", "NE": "NW", "NW": "NE"}

var sprite: AnimatedSprite2D = null
var shadow: AnimatedSprite2D = null
var _move_prefix: String = ""
var _has_idle: bool = false
var _facing: Vector2 = Vector2.DOWN
var _current: String = ""


func build(src, text: String) -> void:
	y_sort_enabled = true
	if src is AnimatedSprite2D and src.sprite_frames != null:
		sprite = _copy_sprite(src)
		if src.material != null:
			var m = src.material.duplicate()
			if m is ShaderMaterial:
				m.set_shader_parameter("line_thickness", 0.0)
				m.set_shader_parameter("line_color", Color(0, 0, 0, 0))
			sprite.material = m
		add_child(sprite)
		for c in src.get_children():
			if c is AnimatedSprite2D and c.sprite_frames != null:
				shadow = _copy_sprite(c)
				sprite.add_child(shadow)
				break
		var prefixes: Dictionary = {}
		for n in sprite.sprite_frames.get_animation_names():
			var s: String = str(n)
			var cut: int = s.rfind("_")
			if cut > 0:
				prefixes[s.substr(0, cut)] = true
		_has_idle = prefixes.has("idle")
		for candidate in ["walk", "run", "move"]:
			if prefixes.has(candidate):
				_move_prefix = candidate
				break
		_play(Vector2.ZERO)
	var marker: Node2D = Node2D.new()
	marker.set_script(load("res://coop/marker.gd"))
	marker.set("label", text)
	marker.set("simple", sprite == null)
	add_child(marker)


func _copy_sprite(src: AnimatedSprite2D) -> AnimatedSprite2D:
	var a: AnimatedSprite2D = AnimatedSprite2D.new()
	a.sprite_frames = src.sprite_frames
	a.position = src.position
	a.scale = src.scale
	a.offset = src.offset
	a.centered = src.centered
	a.modulate = src.modulate
	a.light_mask = src.light_mask
	a.z_index = src.z_index
	a.y_sort_enabled = src.y_sort_enabled
	if src.sprite_frames.has_animation(src.animation):
		a.play(src.animation)
	return a


func update(target: Vector2, dir: Vector2, delta: float) -> void:
	var dist: float = global_position.distance_to(target)
	if dist > 200.0:
		global_position = target
	elif dist > 0.5:
		global_position = global_position.lerp(target, minf(1.0, delta * 12.0))
	if sprite != null:
		_play(dir)


func _play(dir: Vector2) -> void:
	var moving: bool = dir.length() > 0.1
	if moving:
		_facing = dir
	var prefix: String = _move_prefix if (moving and not _move_prefix.is_empty()) else ("idle" if _has_idle else "")
	if prefix.is_empty():
		return
	var pick: Array = _pick(prefix, _facing)
	if pick.is_empty():
		return
	var key: String = str(pick[0]) + ("<" if pick[1] else ">")
	if key == _current:
		return
	_current = key
	sprite.flip_h = pick[1]
	sprite.play(pick[0])
	if shadow != null and shadow.sprite_frames.has_animation(pick[0]):
		shadow.flip_h = pick[1]
		shadow.play(pick[0])


# Finds the animation for a direction; falls back to a mirrored or a four-way one if the hero lacks it.
func _pick(prefix: String, dir: Vector2) -> Array:
	var frames: SpriteFrames = sprite.sprite_frames
	var name8: String = NAMES8[wrapi(roundi(dir.angle() / (PI / 4.0)), 0, 8)]
	var vertical: String = "S" if dir.y >= 0.0 else "N"
	var horizontal: String = "E" if dir.x >= 0.0 else "W"
	for attempt in [[name8, false], [MIRROR.get(name8, ""), true], [horizontal, false], [MIRROR[horizontal], true], [vertical, false], ["S", false]]:
		if str(attempt[0]).is_empty():
			continue
		var anim: String = prefix + "_" + str(attempt[0])
		if frames.has_animation(anim):
			return [anim, attempt[1]]
	return []
