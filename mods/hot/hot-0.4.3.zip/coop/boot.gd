extends Node
## Halls of Torment Co-op - entry point (autoload "HotCoop", injected through override.cfg).

const VERSION: String = "0.4.3"
const PROTO: int = 5

var net: Node
var session: Node
var ui: Node
var cfg: Dictionary = {"puppet_mode": "full", "tether": 900.0, "hud_x": 128, "hud_y": -8, "key": "F1", "show_partner_attacks": true, "xp_share": 0.6}
var _log_file: FileAccess


func _init() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS


func _ready() -> void:
	_open_log()
	_load_cfg()
	info("HoT Co-op %s starting (proto %d)" % [VERSION, PROTO])
	net = _make("res://coop/net.gd", "Net")
	session = _make("res://coop/session.gd", "Session")
	ui = _make("res://coop/ui.gd", "UI")


func _make(path: String, node_name: String) -> Node:
	var script = load(path)
	if script == null:
		info("ERROR: could not load %s" % path)
		return Node.new()
	var n: Node = script.new()
	n.name = node_name
	add_child(n)
	return n


func _open_log() -> void:
	_log_file = FileAccess.open("res://coop/coop.log", FileAccess.WRITE)
	if _log_file == null:
		_log_file = FileAccess.open("user://coop.log", FileAccess.WRITE)


func _load_cfg() -> void:
	var cf: ConfigFile = ConfigFile.new()
	if cf.load("res://coop/config.cfg") != OK:
		return
	for k in cfg.keys():
		cfg[k] = cf.get_value("coop", k, cfg[k])


func info(msg: String) -> void:
	var line: String = "[%s] %s" % [Time.get_time_string_from_system(), msg]
	print("[COOP] " + msg)
	if _log_file:
		_log_file.store_line(line)
		_log_file.flush()


func _notification(what: int) -> void:
	# Give the player's own level-up setting back if the game is closed in the middle of a co-op run.
	if what == NOTIFICATION_WM_CLOSE_REQUEST and session and session.has_method("_restore_settings"):
		session._restore_settings()


func game_version() -> String:
	return str(ProjectSettings.get_setting("application/config/version", ""))


func game(autoload_name: String) -> Node:
	return get_node_or_null("/root/" + autoload_name)
