extends Node
## Game synchronisation.
## Model: both players run the full game locally (own character, level-ups, loot, save file).
## Shared between them: which enemies exist (host decides), enemy health and deaths, enemy positions
## (host corrects), run start, game time, kill count, and the partner's character as a puppet.

const M_CFG: int = 2
const M_START: int = 3
const M_READY: int = 4
const M_FULL: int = 5
const M_SPAWN: int = 6
const M_DMG: int = 7
const M_KILL: int = 8
const M_POS: int = 9
const M_STATE: int = 10
const M_INFO: int = 11
const M_TIME: int = 12
const M_DOWN: int = 13
const M_REVIVE: int = 14
const M_DEAD: int = 15
const M_LEFT: int = 16
const M_DESPAWN: int = 20
const M_NOPE: int = 21
const M_RDY: int = 22
const M_RESUME: int = 23
const M_FULLBEGIN: int = 24
const M_CAMP: int = 25
const M_FX_SPAWN: int = 26
const M_FX_POS: int = 27
const M_FX_END: int = 28
const XP_RULE_NAMES: Array = ["Shared", "Killer takes"]

const DIFFICULTY_NAMES: Array = ["Easy", "Normal", "Hard"]
const DIFFICULTY_HP_BONUS: Array = [0.3, 0.7, 1.3]  # extra enemy max health in co-op
const GHOST_TINT: Color = Color(0.55, 0.8, 1.0, 0.45)
const MENU_PROTECTION: float = 15.0
const REVIVE_TIME: float = 3.0
const REVIVE_RANGE: float = 70.0
const STATE_FALLBACK: Dictionary = {"Overworld": 0, "InGame": 1, "PlayerDied": 3, "PlayerSurvived": 4,
	"TraitSelection": 5, "AbilitySelection": 6, "AbilityTomeSelection": 20, "ShrineOfTorment": 21,
	"RegisterOfHalls": 17, "VaultEntrance": 23, "ChallengeShrineUI": 26}

var coop: Node
var net: Node
var world: Node = null
var player: Node = null
var p_mover: Node = null
var p_input: Node = null
var p_health: Node = null
var active: bool = false          # a co-op run is running on this machine
var coop_run: bool = false        # the run being entered is a co-op run
var partner_in_run: bool = false
var partner_dead: bool = false
var partner_down: bool = false
var partner: Dictionary = {}
var partner_char: String = ""
var difficulty: int = 1
var suppress: bool = false        # client: local enemy spawns are replaced by the host's
var me_down: bool = false
var in_menu: bool = false
var menu_time: float = 0.0
var revive_progress: float = 0.0
var notice: String = ""
var notice_time: float = 0.0
var host_in_run: bool = false     # client: the host is in the middle of a run we are not part of
var puppet_marker: Node = null
var my_marker: Node = null
var _tip_shown: bool = false
var xp_rule: int = 0              # 0 = both get XP gems, 1 = only the killer does
var my_ready: bool = false        # guest: pressed READY
var partner_ready: bool = false   # host: the guest pressed READY
var run_id: int = 0
var down_pos: Vector2 = Vector2.ZERO
var partner_down_pos: Vector2 = Vector2.ZERO
var ghosts: Node = null
var camp_partner: Dictionary = {}
var _my_grave: Node = null
var _partner_grave: Node = null
var _emitters: Array = []
var _saved_artifacts = null
var _start_world: int = 0
var _start_mode: int = 0
var _torment: bool = false
var _catch_up_level: int = 0
var _camp_node: Node = null
var _camp_ident: String = ""
var _t_camp: float = 0.0
var _last_remote_dmg: Dictionary = {}
var _rx_spawns: int = 0
var _t_stats: float = 0.0

var puppet: Node = null
var puppet_mover: Node = null
var puppet_input: Node = null

var _mon: Dictionary = {}         # id -> enemy GameObject
var _dead: Dictionary = {}
var _next_id: int = 1
var _pending_spawn: Array = []
var _dmg_out: Dictionary = {}
var _kill_out: Array = []
var _despawn_out: Array = []
var _applying_remote: bool = false
var _scene_cache: Dictionary = {}
var _spawners: Array = []
var _down_inv: float = -1.0
var _menu_inv: float = -1.0
var _menu_expired: bool = false
var _old_manual = null
var _pos_cursor: int = 0
var _t_state: float = 0.0
var _t_flush: float = 0.0
var _t_pos: float = 0.0
var _t_target: float = 0.0
var _t_time: float = 0.0
var _states: Dictionary = {}


func _ready() -> void:
	coop = get_parent()
	net = coop.net
	if net.has_signal("message"):
		net.message.connect(_on_msg)
		net.peer_connected.connect(_on_peer_connected)
		net.peer_disconnected.connect(_on_peer_disconnected)
	ghosts = load("res://coop/ghosts.gd").new()
	ghosts.name = "Ghosts"
	add_child(ghosts)
	ghosts.setup(self)
	_hook_game()


func _hook_game() -> void:
	var g: Node = coop.game("Global")
	var gs: Node = coop.game("GameState")
	if g == null or gs == null:
		coop.info("Game autoloads not found - running without game hooks")
		return
	if g.has_method("awaitInitialization"):
		await g.awaitInitialization()
	g.WorldReady.connect(_on_world_ready)
	g.WorldRemoved.connect(_on_world_removed)
	var pool = g.get("WorldsPool")
	if pool and pool.has_signal("StartedEnteringHalls"):
		pool.StartedEnteringHalls.connect(_on_entering_halls)
	gs.StateChanged.connect(_on_state_changed)
	get_tree().node_added.connect(_on_node_added)
	var consts: Dictionary = gs.get_script().get_script_constant_map()
	if consts.has("States") and consts["States"] is Dictionary:
		_states = consts["States"]
	coop.info("Game hooks installed")


func st(state_name: String) -> int:
	return int(_states.get(state_name, STATE_FALLBACK.get(state_name, -1)))


func say(text: String, seconds: float = 5.0) -> void:
	notice = text
	notice_time = seconds
	coop.info("NOTICE: " + text)


# ---------------------------------------------------------------- run start

func _on_peer_connected() -> void:
	host_in_run = false
	partner_ready = false
	if net.is_host:
		_send_cfg()
		if active:
			say("%s connected." % net.peer_name)
	else:
		net.send([M_RDY, my_ready])
		if active:
			net.send([M_RESUME, run_id])


func _on_peer_disconnected() -> void:
	partner_ready = false
	_release_camp_puppet()
	_on_partner_gone("disconnected")


func _send_cfg() -> void:
	if net.connected and net.is_host:
		net.send([M_CFG, difficulty, world != null, xp_rule])


func set_ready(value: bool) -> void:
	my_ready = value
	if net.connected and not net.is_host:
		net.send([M_RDY, my_ready])


func _on_entering_halls(world_res) -> void:
	if not net.connected or not net.is_host:
		if not net.connected:
			coop_run = false
		return
	var g: Node = coop.game("Global")
	coop_run = true
	partner_in_run = false
	partner_dead = false
	run_id = (randi() % 1000000000) + 1
	_start_world = int(world_res.get("WorldEnum"))
	_start_mode = int(g.get("SelectedGameMode"))
	_torment = int(coop.game("GameState").get("CurrentState")) == st("ShrineOfTorment")
	if partner_ready:
		net.send(_start_msg(false))
		coop.info("Host starts co-op run %d in world %d (torment=%s)" % [run_id, _start_world, str(_torment)])
	else:
		say("%s was not ready. They can join this run by pressing READY." % net.peer_name, 7.0)


func _start_msg(in_progress: bool) -> Array:
	var artifacts: Array = []
	if _torment:
		var profile = coop.game("Global").get("PlayerProfile")
		if profile is Dictionary and profile.get("ActiveArtifacts") is Array:
			for a in profile["ActiveArtifacts"]:
				artifacts.append(str(a))
	var level: int = int(world.get("Level")) if (in_progress and world != null) else 0
	return [M_START, _start_world, _start_mode, difficulty, xp_rule, _torment, artifacts, run_id, in_progress, level]


func _client_start(msg: Array) -> void:
	var g: Node = coop.game("Global")
	var gs: Node = coop.game("GameState")
	var world_enum: int = int(msg[1])
	if active and run_id == int(msg[7]):
		net.send([M_RESUME, run_id])
		return
	if world != null or g.get("WorldsPool").IsEnteringWorld():
		say("%s started a run, but you are already in one." % net.peer_name)
		net.send([M_NOPE, "is already in a run"])
		return
	var found: bool = false
	for w in g.get("WorldsPool").get("Worlds"):
		if int(w.get("WorldEnum")) == world_enum:
			found = true
			break
	if not found:
		say("You do not own the stage %s picked." % net.peer_name)
		net.send([M_NOPE, "does not own this stage"])
		return
	difficulty = clampi(int(msg[3]), 0, 2)
	xp_rule = clampi(int(msg[4]), 0, 1)
	run_id = int(msg[7])
	_catch_up_level = int(msg[9]) if bool(msg[8]) else 0
	host_in_run = false
	coop_run = true
	partner_in_run = false
	partner_dead = false
	g.set("SelectedGameMode", int(msg[2]))
	var torment: bool = bool(msg[5])
	# Use the host's Torment artifacts for this run; the player's own selection is put back afterwards.
	var profile = g.get("PlayerProfile")
	if torment and msg[6] is Array and profile is Dictionary and profile.get("ActiveArtifacts") is Array:
		_saved_artifacts = profile["ActiveArtifacts"]
		var swapped: Array = _saved_artifacts.duplicate()
		swapped.clear()
		for a in msg[6]:
			swapped.append(str(a))
		profile["ActiveArtifacts"] = swapped
	if int(gs.get("CurrentState")) != st("Overworld"):
		gs.SetState(st("Overworld"))
	_release_camp_puppet()
	coop.info("Client follows host into world %d (run %d, torment=%s, in progress=%s)" % [world_enum, run_id, str(torment), str(msg[8])])
	g.get("WorldsPool").enterWorld(world_enum, torment)


func _on_world_ready() -> void:
	_restore_artifacts()
	world = coop.game("Global").get("World")
	if not coop_run or world == null or not net.connected:
		coop_run = false
		return
	_setup_run()


func _restore_artifacts() -> void:
	if _saved_artifacts == null:
		return
	var profile = coop.game("Global").get("PlayerProfile")
	if profile is Dictionary:
		profile["ActiveArtifacts"] = _saved_artifacts
	_saved_artifacts = null


func _setup_run() -> void:
	player = world.get("Player")
	if player == null:
		return
	p_mover = player.getChildNodeWithMethod("set_worldPosition")
	p_input = player.getChildNodeWithMethod("get_aimDirection")
	p_health = player.getChildNodeWithMethod("addCheatDeathCallable")
	_mon.clear()
	_dead.clear()
	_pending_spawn.clear()
	_dmg_out.clear()
	_kill_out.clear()
	_despawn_out.clear()
	_spawners.clear()
	_next_id = 1
	me_down = false
	in_menu = false
	partner_down = false
	revive_progress = 0.0
	world.child_entered_tree.connect(_on_world_child)
	world.DamageEvent.connect(_on_damage_event)
	world.DeathEvent.connect(_on_death_event)
	if p_health:
		p_health.addCheatDeathCallable(_cheat_death, true)
	# Level-ups queue up on the game's own level-up button instead of interrupting, because the game
	# cannot pause while a partner keeps playing.
	var settings = coop.game("Global").get("CurrentSettings")
	if settings is Dictionary and settings.has("manual_trait_selection"):
		_old_manual = settings["manual_trait_selection"]
		settings["manual_trait_selection"] = true
	if p_mover:
		my_marker = Node2D.new()
		my_marker.set_script(load("res://coop/marker.gd"))
		my_marker.set("ring_color", Color(1.0, 0.85, 0.3))
		p_mover.add_child(my_marker)
	suppress = not net.is_host
	if suppress:
		_client_take_over_spawning(false)
	active = true
	net.send([M_INFO, str(coop.game("Global").get("ChosenPlayerCharacterScene")), net.my_name])
	net.send([M_READY])
	_try_make_puppet()
	if net.is_host and partner_in_run:
		_send_full()
	ghosts.clear()
	my_ready = false
	_send_cfg()
	if _catch_up_level > 0:
		_catch_up(_catch_up_level)
		_catch_up_level = 0
	coop.info("Co-op run set up (host=%s)" % str(net.is_host))


# Joining a run that is already going: hand out the levels the host already has, one by one.
func _catch_up(target_level: int) -> void:
	var w: Node = world
	for _i in 200:
		if not active or world != w or int(w.get("Level")) >= target_level:
			return
		w.addExperience(maxf(1.0, float(w.get("ExperienceThreshold")) - float(w.get("Experience"))), true)
		await get_tree().create_timer(0.3).timeout


func _on_world_removed() -> void:
	if active:
		net.send([M_LEFT])
		coop.info("Co-op run ended")
	_restore_settings()
	active = false
	coop_run = false
	partner_in_run = false
	world = null
	player = null
	my_marker = null
	puppet_marker = null
	puppet = null
	puppet_mover = null
	puppet_input = null
	_mon.clear()
	_spawners.clear()
	suppress = false
	me_down = false
	in_menu = false
	_my_grave = null
	_partner_grave = null
	_emitters.clear()
	partner_ready = false
	my_ready = false
	if ghosts:
		ghosts.clear()
	_send_cfg()


func _restore_settings() -> void:
	_restore_artifacts()
	if _old_manual == null:
		return
	var g: Node = coop.game("Global")
	if g and g.get("CurrentSettings") is Dictionary:
		g.get("CurrentSettings")["manual_trait_selection"] = _old_manual
	_old_manual = null


# ---------------------------------------------------------------- messages

func _on_msg(msg: Array) -> void:
	var t: int = int(msg[0])
	match t:
		M_CFG:
			if msg.size() >= 2 and not net.is_host:
				difficulty = clampi(int(msg[1]), 0, 2)
				if msg.size() >= 3:
					host_in_run = bool(msg[2]) and not active
				if msg.size() >= 4:
					xp_rule = clampi(int(msg[3]), 0, 1)
		M_START:
			if msg.size() >= 10 and not net.is_host:
				_client_start(msg)
		M_RDY:
			if msg.size() >= 2 and net.is_host:
				partner_ready = bool(msg[1])
				if partner_ready and active and not partner_in_run:
					net.send(_start_msg(true))
		M_RESUME:
			if net.is_host and msg.size() >= 2:
				if active and int(msg[1]) == run_id:
					partner_in_run = true
					partner_dead = false
					partner_down = false
					_send_full()
					_try_make_puppet()
					say("%s is back." % net.peer_name)
				else:
					net.send([M_LEFT])
		M_CAMP:
			if msg.size() >= 6:
				camp_partner = {"pos": Vector2(msg[1], msg[2]), "dir": Vector2(msg[3], msg[4]), "ident": str(msg[5]), "age": 0.0}
		M_NOPE:
			if msg.size() >= 2:
				say("%s %s - this run is solo." % [net.peer_name, str(msg[1])])
		M_INFO:
			if msg.size() >= 3:
				partner_char = str(msg[1])
				_try_make_puppet()
		M_READY:
			partner_in_run = true
			partner_dead = false
			partner_down = false
			if active and net.is_host:
				_send_full()
			_try_make_puppet()
			if active and not _tip_shown:
				_tip_shown = true
				say("Co-op: the game never pauses. Level-ups wait on the LEVEL UP button.", 10.0)
		M_LEFT:
			host_in_run = false
			_on_partner_gone("left the run")
		M_DEAD:
			partner_dead = true
			_on_partner_gone("died")
		M_STATE:
			if msg.size() >= 10:
				partner = {"pos": Vector2(msg[1], msg[2]), "dir": Vector2(msg[3], msg[4]), "aim": Vector2(msg[5], msg[6]),
					"hp": int(msg[7]), "maxhp": int(msg[8]), "level": int(msg[9]), "flags": int(msg[10]) if msg.size() > 10 else 0,
					"rev": float(msg[11]) if msg.size() > 11 else 0.0}
				partner_down = (partner["flags"] & 1) != 0
				if not partner_down and _partner_grave != null:
					_clear_grave(false)
		_:
			if active and world != null:
				_on_run_msg(t, msg)


func _on_run_msg(t: int, msg: Array) -> void:
	match t:
		M_SPAWN, M_FULL:
			if net.is_host or msg.size() < 2 or not (msg[1] is Array):
				return
			for e in msg[1]:
				if e is Array and e.size() >= 4:
					_client_spawn(int(e[0]), str(e[1]), Vector2(e[2], e[3]), int(e[4]) if e.size() > 4 else -1)
		M_DMG:
			if msg.size() >= 2 and msg[1] is PackedInt32Array:
				var arr: PackedInt32Array = msg[1]
				for i in range(0, arr.size() - 1, 2):
					_apply_remote_damage(arr[i], arr[i + 1])
		M_KILL:
			if msg.size() >= 2 and msg[1] is PackedInt32Array:
				for id in msg[1]:
					_apply_remote_kill(id)
		M_DESPAWN:
			if not net.is_host and msg.size() >= 2 and msg[1] is PackedInt32Array:
				for id in msg[1]:
					var n = _mon.get(id)
					if n != null and is_instance_valid(n):
						_dead[id] = true
						n.queue_free()
		M_POS:
			if not net.is_host and msg.size() >= 3 and msg[1] is PackedInt32Array and msg[2] is PackedFloat32Array:
				_apply_positions(msg[1], msg[2])
		M_TIME:
			if not net.is_host and msg.size() >= 2 and world.has_method("set_game_time"):
				if absf(float(world.get("GameTime")) - float(msg[1])) > 2.0:
					world.set_game_time(float(msg[1]))
		M_FULLBEGIN:
			if not net.is_host:
				_client_reset_enemies()
		M_DOWN:
			partner_down = true
			partner_down_pos = Vector2(msg[1], msg[2]) if msg.size() >= 3 else partner.get("pos", Vector2.ZERO)
			_clear_grave(false)
			_partner_grave = _make_grave(partner_down_pos, net.peer_name)
			if me_down:
				_real_death()
		M_REVIVE:
			if me_down:
				_get_up()
		M_FX_SPAWN:
			if bool(coop.cfg.get("show_partner_attacks", true)):
				ghosts.on_spawn(msg)
		M_FX_POS:
			if msg.size() >= 3 and msg[1] is PackedInt32Array and msg[2] is PackedFloat32Array:
				ghosts.on_pos(msg[1], msg[2])
		M_FX_END:
			if msg.size() >= 2 and msg[1] is PackedInt32Array:
				ghosts.on_end(msg[1])


func _on_partner_gone(reason: String) -> void:
	if not partner_in_run and puppet == null:
		return
	partner_in_run = false
	partner_down = false
	revive_progress = 0.0
	_remove_puppet()
	_clear_grave(false)
	if ghosts:
		ghosts.clear()
	if active:
		say("%s %s. You continue alone." % [net.peer_name, reason])
		if suppress:
			_client_take_over_spawning(true)
		if me_down:
			_real_death()
		if in_menu:
			_end_menu_protection(false)


# ---------------------------------------------------------------- enemies

func _is_enemy(node: Node) -> bool:
	if not node.is_class("GameObject") or node == puppet:
		return false
	if node.is_in_group("Player") or node.is_in_group("FromPlayer"):
		return false
	if node.getChildNodeWithMethod("applyDamage") == null:
		return false
	for c in node.get_children():
		if _is_enemy_locator(c):
			return true
		for cc in c.get_children():
			if _is_enemy_locator(cc):
				return true
	return false


func _is_enemy_locator(n: Node) -> bool:
	return n.is_class("Locator") and str(n.get("LocatorPoolName")) == "Enemies"


func _on_world_child(node: Node) -> void:
	if not active or node.has_meta("coop_id"):
		return
	if not _is_enemy(node):
		if partner_in_run and node.is_class("GameObject") and bool(coop.cfg.get("show_partner_attacks", true)):
			ghosts.on_world_child(node)
		return
	var path: String = node.scene_file_path
	if path.is_empty():
		return  # built at runtime, cannot be recreated on the other side: stays local
	if net.is_host:
		var id: int = _next_id
		_next_id += 1
		_register(id, node)
		if partner_in_run:
			_pending_spawn.append(id)
	elif suppress:
		node.set_meta("coop_id", -1)
		node.set("visible", false)
		node.queue_free()


func _register(id: int, node: Node) -> void:
	node.set_meta("coop_id", id)
	if node.is_in_group("Lord") or node.has_node("BossHealthBar"):
		node.set_meta("coop_boss", true)
	_mon[id] = node
	node.tree_exiting.connect(_on_enemy_exit.bind(id))


func _on_enemy_exit(id: int) -> void:
	_mon.erase(id)
	_last_remote_dmg.erase(id)
	if _dead.has(id):
		_dead.erase(id)
	elif active and net.is_host and partner_in_run and world != null and not world.get("is_being_removed"):
		_despawn_out.append(id)


func _enemy_pos(node: Node) -> Vector2:
	var provider = node.getChildNodeWithMethod("get_worldPosition")
	if provider:
		return provider.get_worldPosition()
	return node.global_position


func _health_of(node: Node):
	return node.getChildNodeWithMethod("applyDamage")


func _apply_hp_bonus(node: Node) -> void:
	if node.has_meta("coop_hp"):
		return
	node.set_meta("coop_hp", true)
	var ps = _scene("res://Modifiers/MaxHealthBuff.tscn")
	if ps == null:
		return
	var buff: Node = ps.instantiate()
	buff.set("AddMaxHealthPercent", DIFFICULTY_HP_BONUS[difficulty])
	buff.set("AddHealthOnActivate", true)
	buff.set("Name", "Co-op")
	node.add_child(buff)


func _scene(path: String):
	if _scene_cache.has(path):
		return _scene_cache[path]
	var ps = null
	if ResourceLoader.exists(path):
		ps = load(path)
	if ps == null:
		coop.info("Scene not loadable: %s" % path)
	_scene_cache[path] = ps
	return ps


func _flush_spawns() -> void:
	if _pending_spawn.is_empty():
		return
	var batch: Array = []
	for id in _pending_spawn:
		var n = _mon.get(id)
		if n == null or not is_instance_valid(n) or n.is_queued_for_deletion():
			continue
		_apply_hp_bonus(n)
		var p: Vector2 = _enemy_pos(n)
		batch.append([id, n.scene_file_path, p.x, p.y])
		if batch.size() >= 30:
			net.send([M_SPAWN, batch])
			batch = []
	_pending_spawn.clear()
	if not batch.is_empty():
		net.send([M_SPAWN, batch])


func _send_full() -> void:
	var batch: Array = []
	_pending_spawn.clear()
	net.send([M_FULLBEGIN])
	for id in _mon.keys():
		var n = _mon[id]
		if not is_instance_valid(n) or n.is_queued_for_deletion():
			continue
		_apply_hp_bonus(n)
		var p: Vector2 = _enemy_pos(n)
		var h = _health_of(n)
		batch.append([id, n.scene_file_path, p.x, p.y, int(h.get_health()) if h else -1])
		if batch.size() >= 30:
			net.send([M_FULL, batch])
			batch = []
	if not batch.is_empty():
		net.send([M_FULL, batch])
	net.send([M_TIME, float(world.get("GameTime"))])
	_send_cfg()
	coop.info("Full sync sent (%d enemies)" % _mon.size())


func _client_spawn(id: int, path: String, pos: Vector2, hp: int) -> void:
	if _mon.has(id) or _dead.has(id):
		return
	var ps = _scene(path)
	if ps == null:
		return
	var node: Node = ps.instantiate()
	_rx_spawns += 1
	_register(id, node)
	world.add_child(node)
	node.global_position = pos
	var with_difficulty: Array = []
	node.getChildNodesWithMethod("set_difficulty", with_difficulty)
	if not with_difficulty.is_empty():
		var d = 1.0
		var x = 1.0
		var rank = world.get("TormentRank")
		if rank and rank.get_script():
			var sd = rank.get_script().get("torment_difficulty")
			var sx = rank.get_script().get("rank_xp_modifier")
			if sd != null and sx != null:
				d = sd
				x = sx
		for c in with_difficulty:
			c.set_difficulty(d, x)
	_apply_hp_bonus(node)
	if hp > 0:
		var h = _health_of(node)
		if h and int(h.get_health()) > hp:
			h.set("_currentHealth", hp)
	world.emit_signal("EnemyAppeared", node)


func _on_damage_event(target, _source, actual_damage, _total_damage) -> void:
	if _applying_remote or not partner_in_run or target == null or int(actual_damage) <= 0:
		return
	if target.has_meta("coop_id"):
		var id: int = int(target.get_meta("coop_id"))
		if id > 0:
			_dmg_out[id] = int(_dmg_out.get(id, 0)) + int(actual_damage)


func _on_death_event(dead, _killer) -> void:
	if dead == null or not dead.has_meta("coop_id"):
		return
	var id: int = int(dead.get_meta("coop_id"))
	if id <= 0:
		return
	_dead[id] = true
	if not _applying_remote and partner_in_run:
		_kill_out.append(id)


func _flush_damage() -> void:
	if not _dmg_out.is_empty():
		var arr: PackedInt32Array = PackedInt32Array()
		for id in _dmg_out.keys():
			arr.append(id)
			arr.append(_dmg_out[id])
		_dmg_out.clear()
		net.send([M_DMG, arr])
	if not _kill_out.is_empty():
		net.send([M_KILL, PackedInt32Array(_kill_out)])
		_kill_out.clear()
	if not _despawn_out.is_empty():
		net.send([M_DESPAWN, PackedInt32Array(_despawn_out)])
		_despawn_out.clear()


func _apply_remote_damage(id: int, dmg: int) -> void:
	var n = _mon.get(id)
	if n == null or not is_instance_valid(n) or dmg <= 0:
		return
	var h = _health_of(n)
	if h == null:
		return
	var cur = h.get("_currentHealth")
	if cur == null:
		return
	h.set("_currentHealth", maxi(1, int(cur) - dmg))
	_last_remote_dmg[id] = dmg
	if h.has_method("force_health_update_signals"):
		h.force_health_update_signals()


func _apply_remote_kill(id: int) -> void:
	var n = _mon.get(id)
	if n == null or not is_instance_valid(n) or n.is_queued_for_deletion():
		_dead[id] = true
		return
	var h = _health_of(n)
	_dead[id] = true
	if xp_rule == 1:
		var drops: Array = []
		n.getChildNodesWithMethod("get_gem_count", drops)
		for d in drops:
			d.set("MinGems", 0)
			d.set("MaxGems", 0)
	_applying_remote = true
	if h:
		h.set("_currentHealth", 1)
		# the killing blow shows the partner's real hit, never an invented number
		h.applyDamage(clampi(int(_last_remote_dmg.get(id, 1)), 1, 9999999), null)
		if is_instance_valid(n) and not n.is_queued_for_deletion() and h.has_method("is_dead") and not h.is_dead():
			if h.has_method("instakill"):
				h.instakill()
	if is_instance_valid(n) and not n.is_queued_for_deletion() and (h == null or not h.is_dead()):
		n.queue_free()
	_applying_remote = false
	if world.has_method("addToKillCount"):
		world.addToKillCount(1)


func _send_positions() -> void:
	var ids: Array = _mon.keys()
	if ids.is_empty():
		return
	var boss_ids: PackedInt32Array = PackedInt32Array()
	var boss_pos: PackedFloat32Array = PackedFloat32Array()
	for id in ids:
		var b = _mon[id]
		if is_instance_valid(b) and b.has_meta("coop_boss") and b.is_inside_tree() and boss_ids.size() < 40:
			var bp: Vector2 = _enemy_pos(b)
			boss_ids.append(id)
			boss_pos.append(bp.x)
			boss_pos.append(bp.y)
	if not boss_ids.is_empty():
		net.send([M_POS, boss_ids, boss_pos], false)
	for _packet in 2:
		var out_ids: PackedInt32Array = PackedInt32Array()
		var out_pos: PackedFloat32Array = PackedFloat32Array()
		for _i in 50:
			if _pos_cursor >= ids.size():
				_pos_cursor = 0
				break
			var id: int = ids[_pos_cursor]
			_pos_cursor += 1
			var n = _mon[id]
			if is_instance_valid(n) and n.is_inside_tree():
				var p: Vector2 = _enemy_pos(n)
				out_ids.append(id)
				out_pos.append(p.x)
				out_pos.append(p.y)
		if not out_ids.is_empty():
			net.send([M_POS, out_ids, out_pos], false)
		if _pos_cursor == 0:
			break


func _apply_positions(ids: PackedInt32Array, pos: PackedFloat32Array) -> void:
	for i in ids.size():
		if i * 2 + 1 >= pos.size():
			return
		var n = _mon.get(ids[i])
		if n == null or not is_instance_valid(n) or not n.is_inside_tree():
			continue
		var provider = n.getChildNodeWithMethod("set_worldPosition")
		if provider == null:
			continue
		var target: Vector2 = Vector2(pos[i * 2], pos[i * 2 + 1])
		var cur: Vector2 = provider.get_worldPosition()
		var dist: float = cur.distance_to(target)
		if n.has_meta("coop_boss"):
			if dist > 120.0:
				provider.set_worldPosition(target)
			elif dist > 6.0:
				provider.set_worldPosition(cur.lerp(target, 0.5))
		elif dist > 260.0:
			provider.set_worldPosition(target)
		elif dist > 28.0:
			provider.set_worldPosition(cur.lerp(target, 0.3))


func _retarget() -> void:
	if player == null or not is_instance_valid(player):
		return
	var use_puppet: bool = puppet != null and is_instance_valid(puppet) and partner_in_run and not partner_down
	var my_pos: Vector2 = world.get_player_position()
	var other_pos: Vector2 = partner.get("pos", my_pos)
	for id in _mon.keys():
		var n = _mon[id]
		if not is_instance_valid(n) or not n.is_inside_tree():
			continue
		var want: int = 0
		if use_puppet:
			var p: Vector2 = _enemy_pos(n)
			if me_down or p.distance_squared_to(other_pos) < p.distance_squared_to(my_pos):
				want = 1
		if int(n.get_meta("coop_tgt", 0)) == want:
			continue
		var input = n.getChildNodeWithMethod("set_target")
		if input:
			input.set_target(puppet if want == 1 else player)
		n.set_meta("coop_tgt", want)


func _on_node_added(node: Node) -> void:
	if not active or not suppress or world == null:
		return
	if node.has_method("spawn_wave") and world.is_ancestor_of(node):
		_spawners.append(node)
		node.set_process.call_deferred(false)


func _client_take_over_spawning(resume: bool) -> void:
	if resume:
		suppress = false
		for s in _spawners:
			if is_instance_valid(s):
				s.set_process(true)
		_spawners.clear()
		return
	var stack: Array = [world]
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		if n.has_method("spawn_wave"):
			_spawners.append(n)
			n.set_process(false)
		elif n != player:
			stack.append_array(n.get_children())
	# The host decides where far-away enemies are moved to, so the local teleporter goes.
	if p_mover:
		for c in p_mover.get_children():
			if c.scene_file_path.contains("Monster_Teleporter"):
				c.queue_free()


# ---------------------------------------------------------------- partner puppet

func _try_make_puppet() -> void:
	if not active or world == null or puppet != null or not partner_in_run or partner_char.is_empty():
		return
	if str(coop.cfg["puppet_mode"]) == "full":
		_make_full_puppet()
	if puppet == null:
		_make_simple_puppet()
	if puppet != null:
		coop.info("Partner puppet created (%s)" % partner_char)


func _make_full_puppet() -> void:
	var ps = _scene(partner_char)
	if ps == null:
		return
	var go: Node = ps.instantiate()
	for grp in ["Player", "FromPlayer"]:
		if go.is_in_group(grp):
			go.remove_from_group(grp)
	var mover: Node = null
	var input: Node = null
	for c in go.get_children():
		if mover == null and c.has_method("set_worldPosition") and c.has_method("set_targetDirection"):
			mover = c
		elif input == null and c.has_method("get_aimDirection"):
			input = c
	if mover == null or input == null:
		go.free()
		return
	for c in go.get_children():
		if c == mover or c == input or c.is_class("Health"):
			continue
		go.remove_child(c)
		c.free()
	for c in mover.get_children():
		var keep: bool = c.is_class("AnimatedSprite2D") or c.is_class("CollisionShape2D") or c.is_class("PointLight2D")
		if not keep and c.get_script() == null and c.get_class() == "Node2D":
			keep = true
		if c.is_class("Camera2D") or c.is_class("Locator"):
			keep = false
		if keep:
			if c.is_class("PointLight2D"):
				c.set_script(null)
			continue
		mover.remove_child(c)
		c.free()
	mover.set("collision_layer", 0)
	mover.set("collision_mask", 0)
	input.set_script(load("res://coop/puppet_input.gd"))
	input.process_mode = Node.PROCESS_MODE_INHERIT
	go.set_meta("coop_id", -2)
	world.add_child(go)
	var start: Vector2 = partner.get("pos", world.get_player_position())
	mover.global_position = start
	var h = go.getChildNodeWithMethod("setInvincibleForTime")
	if h:
		h.setInvincibleForTime(9999999.0)
	puppet = go
	puppet_mover = mover
	puppet_input = input
	_decorate_puppet(mover)


func _make_simple_puppet() -> void:
	var go = ClassDB.instantiate("GameObject")
	if go == null:
		return
	var body: Node2D = Node2D.new()
	body.set_script(load("res://coop/puppet_input.gd"))
	body.name = "CoopBody"
	go.add_child(body)
	go.set_meta("coop_id", -2)
	world.add_child(go)
	body.global_position = partner.get("pos", world.get_player_position())
	puppet = go
	puppet_mover = body
	puppet_input = body
	_decorate_puppet(body)


func _decorate_puppet(parent: Node) -> void:
	var marker: Node2D = Node2D.new()
	marker.set_script(load("res://coop/marker.gd"))
	marker.name = "CoopMarker"
	marker.set("label", net.peer_name)
	marker.set("simple", parent == puppet_input and not parent.is_class("CharacterBody2D"))
	parent.add_child(marker)
	puppet_marker = marker
	for c in parent.get_children():
		if c.has_method("set_outline"):
			for m in c.get_method_list():
				if m["name"] == "set_outline":
					if m["args"].size() == 1 and m["args"][0]["type"] == TYPE_COLOR:
						c.set_outline(Color(0.35, 0.65, 1.0))
					break


func _remove_puppet() -> void:
	if puppet != null and is_instance_valid(puppet):
		puppet.queue_free()
	puppet = null
	puppet_mover = null
	puppet_input = null
	puppet_marker = null


func _update_puppet(delta: float) -> void:
	if puppet == null or not is_instance_valid(puppet) or partner.is_empty():
		return
	var target: Vector2 = partner["pos"]
	var dir: Vector2 = partner["dir"]
	if puppet_mover.has_method("set_targetDirection"):
		puppet_mover.set_targetDirection(dir)
	var cur: Vector2 = puppet_mover.global_position
	var dist: float = cur.distance_to(target)
	if dist > 220.0:
		puppet_mover.global_position = target
	elif dist > 1.5:
		puppet_mover.global_position = cur.lerp(target, minf(1.0, delta * 12.0))
	puppet_input.set("walk", dir)
	puppet_input.set("aim", partner["aim"])
	puppet.set("trackedGlobalPosition", puppet_mover.global_position)
	puppet_mover.modulate = GHOST_TINT if partner_down else Color.WHITE
	if _partner_grave != null and is_instance_valid(_partner_grave):
		_partner_grave.set_state(true, revive_progress)


# ---------------------------------------------------------------- local player rules

func _send_state() -> void:
	if player == null or not is_instance_valid(player):
		return
	var pos: Vector2 = world.get_player_position()
	var dir: Vector2 = Vector2.ZERO
	var aim: Vector2 = Vector2.DOWN
	if p_input:
		dir = p_input.get_inputWalkDir()
		aim = p_input.get_aimDirection()
	var hp: int = 0
	var maxhp: int = 1
	if p_health:
		hp = int(p_health.get_health())
		maxhp = int(p_health.get_maxHealth())
	var flags: int = (1 if me_down else 0) | (2 if in_menu else 0)
	net.send([M_STATE, pos.x, pos.y, dir.x, dir.y, aim.x, aim.y, hp, maxhp, int(world.get("Level")), flags, revive_progress], false)


func _tether() -> void:
	if not partner_in_run or partner.is_empty() or p_mover == null or me_down:
		return
	var limit: float = float(coop.cfg["tether"])
	var my_pos: Vector2 = p_mover.get_worldPosition()
	var other: Vector2 = partner["pos"]
	var dist: float = my_pos.distance_to(other)
	if dist > limit and dist < limit * 4.0:
		p_mover.set_worldPosition(other + (my_pos - other) / dist * limit)


func _cheat_death() -> void:
	# Called by the game when the local player would die and has no other revive left.
	if p_health:
		if int(p_health.get("_currentHealth")) <= 0:
			p_health.set("_currentHealth", 1)
		_down_inv = p_health.setInvincibleForTime(99999.0)
	if not partner_in_run or partner_down or partner_dead:
		_real_death.call_deferred()
		return
	# The body stays as a grave; the player keeps roaming as a ghost that cannot attack or be hurt.
	me_down = true
	down_pos = world.get_player_position()
	_emitters.clear()
	player.getChildNodesWithMethod("set_emitting", _emitters)
	if p_mover:
		p_mover.modulate = GHOST_TINT
	_clear_grave(true)
	_my_grave = _make_grave(down_pos, "")
	net.send([M_DOWN, down_pos.x, down_pos.y])
	_send_state()
	coop.info("Local player is down")


func _ghost_tick() -> void:
	for e in _emitters:
		if is_instance_valid(e):
			e.set_emitting(false)
	if _my_grave != null and is_instance_valid(_my_grave):
		_my_grave.set_state(true, float(partner.get("rev", 0.0)))


func _make_grave(pos: Vector2, text: String) -> Node:
	if world == null:
		return null
	var grave: Node2D = Node2D.new()
	grave.set_script(load("res://coop/marker.gd"))
	grave.set("grave", true)
	grave.set("label", text)
	world.add_child(grave)
	grave.global_position = pos
	return grave


func _clear_grave(mine: bool) -> void:
	var g: Node = _my_grave if mine else _partner_grave
	if g != null and is_instance_valid(g):
		g.queue_free()
	if mine:
		_my_grave = null
	else:
		_partner_grave = null


# The moment a player gets back up: a big shockwave and a short damage boost for both.
func _revive_burst(pos: Vector2) -> void:
	var forces: Node = coop.game("Forces")
	if forces and forces.has_method("RadialBlast"):
		forces.RadialBlast(pos, 280, 420, 1)
	var fx: Node = coop.game("Fx")
	if fx and fx.has_method("show_revive"):
		fx.show_revive(pos, Callable())
	var ps = _scene("res://Modifiers/DamageBuff.tscn")
	if ps != null and player != null and is_instance_valid(player):
		var buff: Node = ps.instantiate()
		buff.set("AddDamagePercent", 0.3)
		buff.set("RemoveAfterTime", 8.0)
		buff.set("Name", "Second Wind")
		player.add_child(buff)





func _get_up() -> void:
	me_down = false
	_clear_grave(true)
	if p_mover:
		p_mover.set_worldPosition(down_pos)
		p_mover.modulate = Color.WHITE
	if p_health:
		if _down_inv > 0:
			p_health.removeInvincibleForTime(_down_inv)
			_down_inv = -1.0
		p_health.add_health(maxi(1, int(p_health.get_maxHealth() * 0.5)))
		p_health.setInvincibleForTime(2.0)
	var auto = p_input.get("autoEmitToggle") if p_input else false
	for e in _emitters:
		if is_instance_valid(e):
			e.set_emitting(auto == true)
	_emitters.clear()
	_revive_burst(down_pos)
	coop.info("Local player was revived")


func _real_death() -> void:
	if world == null or player == null or not is_instance_valid(player):
		return
	me_down = false
	_clear_grave(true)
	if p_health:
		p_health.removeCheatDeathCallable(_cheat_death)
		if _down_inv > 0:
			p_health.removeInvincibleForTime(_down_inv)
			_down_inv = -1.0
	if p_mover:
		p_mover.modulate = Color.WHITE
	if partner_in_run:
		net.send([M_DEAD])
	coop.info("Local player died")
	var gs: Node = coop.game("GameState")
	if p_health:
		p_health.set("_currentHealth", 1)
		p_health.applyDamage(99999999, null)
	if int(gs.get("CurrentState")) != st("PlayerDied"):
		world.TriggerDeathEvent(player, null)


func _blast(revive_fx: bool) -> void:
	var forces: Node = coop.game("Forces")
	var pos: Vector2 = world.get_player_position()
	if forces and forces.has_method("RadialBlast"):
		forces.RadialBlast(pos, 180, 250, 1)
	var fx: Node = coop.game("Fx")
	if revive_fx and fx and fx.has_method("show_revive"):
		fx.show_revive(pos, Callable())


func _revive_logic(delta: float) -> void:
	if not partner_down or me_down or not partner_in_run or partner.is_empty():
		revive_progress = 0.0
		return
	if world.get_player_position().distance_to(partner_down_pos) <= REVIVE_RANGE:
		revive_progress += delta / REVIVE_TIME
		if revive_progress >= 1.0:
			revive_progress = 0.0
			partner_down = false
			partner["flags"] = 0
			net.send([M_REVIVE])
			_clear_grave(false)
			_revive_burst(partner_down_pos)
	else:
		revive_progress = maxf(0.0, revive_progress - delta)


func _on_state_changed(new_state, old_state) -> void:
	if world == null:
		_camp_state_gate(new_state)
		return
	if not active:
		return
	var ingame: int = st("InGame")
	var ended: bool = new_state == st("PlayerDied") or new_state == st("PlayerSurvived") or new_state == st("Overworld")
	if new_state != ingame and not ended and not in_menu and partner_in_run and not me_down:
		in_menu = true
		_menu_expired = false
		menu_time = MENU_PROTECTION
		if p_health:
			_menu_inv = p_health.setInvincibleForTime(9999.0)
	elif in_menu and (new_state == ingame or ended):
		var was_level_up: bool = old_state == st("TraitSelection") or old_state == st("AbilitySelection") or old_state == st("AbilityTomeSelection")
		_end_menu_protection(was_level_up and new_state == ingame)


func _end_menu_protection(push_back: bool) -> void:
	in_menu = false
	if p_health and is_instance_valid(p_health):
		if _menu_inv > 0:
			p_health.removeInvincibleForTime(_menu_inv)
		if push_back:
			p_health.setInvincibleForTime(0.5)
	_menu_inv = -1.0
	if push_back and world != null:
		_blast(false)


func _menu_logic(delta: float) -> void:
	if not in_menu or _menu_expired:
		return
	menu_time -= delta
	if menu_time > 0.0:
		return
	_menu_expired = true
	if p_health and _menu_inv > 0:
		p_health.removeInvincibleForTime(_menu_inv)
		_menu_inv = -1.0
	var gs: Node = coop.game("GameState")
	var menus: Node = coop.game("GlobalMenus")
	if menus and int(gs.get("CurrentState")) == st("TraitSelection"):
		var sel = menus.get("traitSelectionUI")
		if sel and sel.has_method("select_first") and sel.has_method("on_selection_confirmed"):
			sel.select_first()
			sel.on_selection_confirmed(false)


func _process(delta: float) -> void:
	if notice_time > 0.0:
		notice_time -= delta
	if not active or world == null or not is_instance_valid(world):
		_camp_tick(delta)
		return
	if not net.connected and partner_in_run:
		_on_partner_gone("disconnected")
	if partner_in_run and get_tree().paused:
		get_tree().paused = false
	_update_puppet(delta)
	if me_down:
		_ghost_tick()
	if ghosts:
		ghosts.tick(delta)
	_tether()
	_revive_logic(delta)
	_menu_logic(delta)
	if not partner_in_run:
		return
	_t_state += delta
	if _t_state >= 0.066:
		_t_state = 0.0
		_send_state()
	_t_flush += delta
	if _t_flush >= 0.1:
		_t_flush = 0.0
		if net.is_host:
			_flush_spawns()
		_flush_damage()
	_t_stats += delta
	if _t_stats >= 20.0:
		_t_stats = 0.0
		coop.info("stats: enemies=%d spawns_received=%d ping=%dms time=%.0f level=%s" % [_mon.size(), _rx_spawns, net.ping_ms, float(world.get("GameTime")), str(world.get("Level"))])
	_t_target += delta
	if _t_target >= 0.5:
		_t_target = 0.0
		_retarget()
	if net.is_host:
		_t_pos += delta
		if _t_pos >= 0.12:
			_t_pos = 0.0
			_send_positions()
		_t_time += delta
		if _t_time >= 1.0:
			_t_time = 0.0
			net.send([M_TIME, float(world.get("GameTime"))], false)



# ---------------------------------------------------------------- reconnect

func _client_reset_enemies() -> void:
	# The host is about to send the full enemy list (first join or reconnect): drop everything local.
	for c in world.get_children():
		if c != puppet and _is_enemy(c):
			c.set_meta("coop_id", -1)
			c.queue_free()
	_mon.clear()
	_dead.clear()
	_dmg_out.clear()
	_kill_out.clear()
	partner_in_run = true
	partner_dead = false
	if not suppress:
		suppress = true
		_client_take_over_spawning(false)
	_try_make_puppet()


# ---------------------------------------------------------------- camp (overworld)

func _camp_tick(delta: float) -> void:
	var gs: Node = coop.game("GameState")
	if gs == null or world != null:
		return
	var ow = gs.get("CurrentScene")
	if ow == null or not is_instance_valid(ow) or not ow.has_method("switch_player_character"):
		return
	if not net.connected:
		_release_camp_puppet()
		return
	_t_camp += delta
	if _t_camp >= 0.1:
		_t_camp = 0.0
		var me = ow.get("current_player_character")
		if me != null and is_instance_valid(me):
			var provider = me.getChildNodeWithMethod("get_worldPosition")
			var vel_node = me.getChildNodeWithMethod("get_targetVelocity")
			if provider:
				var pos: Vector2 = provider.get_worldPosition()
				var dir: Vector2 = vel_node.get_targetVelocity().normalized() if vel_node else Vector2.ZERO
				net.send([M_CAMP, pos.x, pos.y, dir.x, dir.y, str(coop.game("Global").get("ChosenPlayerCharacterIdentifier"))], false)
	_update_camp_puppet(ow, delta)


# The run starts only when the guest is ready, and only the host can start it.
# In a lobby a run starts only through the host, and only once the guest pressed READY.
func _camp_state_gate(new_state) -> void:
	if not net.connected or coop.game("Global").get("WorldsPool").IsEnteringWorld():
		return
	var starters: Array = [st("RegisterOfHalls"), st("ShrineOfTorment"), st("VaultEntrance")]
	var reason: String = ""
	if new_state == st("ChallengeShrineUI"):
		reason = "Challenges are not available in co-op. Leave the lobby to play them."
	elif new_state in starters:
		if not net.is_host:
			reason = "Only %s can start the run. Leave the lobby to play alone." % net.peer_name
		elif not partner_ready:
			reason = "%s is not ready yet." % net.peer_name
	if reason.is_empty():
		return
	say(reason, 4.0)
	coop.game("GameState").SetState.call_deferred(st("Overworld"))


func _update_camp_puppet(ow: Node, delta: float) -> void:
	if camp_partner.is_empty():
		return
	camp_partner["age"] += delta
	if camp_partner["age"] > 2.5:
		_release_camp_puppet()
		camp_partner = {}
		return
	var ident: String = camp_partner["ident"]
	if ident != _camp_ident or _camp_node == null or not is_instance_valid(_camp_node):
		_release_camp_puppet()
		_camp_ident = ident
		_camp_node = Node2D.new()
		_camp_node.set_script(load("res://coop/camp_puppet.gd"))
		ow.add_child(_camp_node)
		_camp_node.global_position = camp_partner["pos"]
		_camp_node.build(_find_camp_sprite(ow, ident), net.peer_name)
		coop.info("Camp puppet for %s (%s)" % [net.peer_name, ident])
	_camp_node.update(camp_partner["pos"], camp_partner["dir"], delta)


func _find_camp_sprite(ow: Node, ident: String):
	if ident.is_empty():
		return null
	for c in ow.get_children():
		if not c.is_class("GameObject"):
			continue
		var sel = c.getChildNodeWithMethod("get_playerCharacterScenePath")
		if sel != null and str(sel.get("PlayerCharacterIdentifier")) == ident:
			return sel.get("CharacterSprite")
	return null


func _release_camp_puppet() -> void:
	if _camp_node != null and is_instance_valid(_camp_node):
		_camp_node.queue_free()
	_camp_node = null
	_camp_ident = ""