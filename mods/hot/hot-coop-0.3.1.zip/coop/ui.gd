extends CanvasLayer
## Co-op interface, built from the game's own fonts, frames and buttons:
##  - a CO-OP button in the camp HUD (next to MENU) and a guidance banner under "Choose a hero!"
##  - a dialog in the style of the game's modal dialogs that walks both players through the steps
##  - in a run: partner frame, off-screen pointer, down / revive / protection banners

const BLUE: Color = Color(0.35, 0.65, 1.0)
const GOLD: Color = Color(0.95, 0.8, 0.35)
const ORANGE: Color = Color(0.98, 0.506, 0.0)
const DIM: String = "#8c8478"
const DONE: String = "#9fbf7f"
const NOW: String = "#f2cc59"
const FONT: String = "res://UI/Fonts/EBGaramond-Regular.ttf"
const GFX: String = "res://Sprites/UI_gfx/"

var coop: Node
var net: Node
var session: Node
var root: Control
var font: Font = null
var ow_button: Button
var ow_ready: Button
var banner: Label
var dialog: ColorRect
var box: Control
var steps: RichTextLabel
var footer: Label
var btn_main: Button
var btn_difficulty: Button
var btn_leave: Button
var btn_xp: Button
var btn_rejoin: Button
var partner_box: Control
var partner_name: Label
var partner_info: Label
var partner_bar: TextureProgressBar
var revive_bar: TextureProgressBar
var pointer: Control
var pointer_arrow: Polygon2D
var _toggle_key: int = KEY_F1
var _refresh: float = 0.0
var _ow_button_placed: bool = false


func _ready() -> void:
	coop = get_parent()
	net = coop.net
	session = coop.session
	layer = 90
	_toggle_key = OS.find_keycode_from_string(str(coop.cfg["key"]))
	if _toggle_key == KEY_NONE:
		_toggle_key = KEY_F1
	if ResourceLoader.exists(FONT):
		font = load(FONT)
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if ResourceLoader.exists("res://UI/UI_Theme.tres"):
		root.theme = load("res://UI/UI_Theme.tres")
	add_child(root)
	_build_hud()
	_build_banner()
	_build_ow_button()
	_build_dialog()
	if net.has_signal("status_changed"):
		net.status_changed.connect(_update_dialog)
	_update_dialog()


# ---------------------------------------------------------------- building blocks

func _tex(path: String) -> Texture2D:
	if ResourceLoader.exists(path):
		return load(path)
	return null


func _label(text: String, size: int, color: Color = Color.WHITE) -> Label:
	var l: Label = Label.new()
	l.text = text
	if font:
		l.add_theme_font_override("font", font)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_shadow_color", Color.BLACK)
	l.add_theme_constant_override("shadow_offset_x", 0)
	l.add_theme_constant_override("shadow_offset_y", 2)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _fill(c: Control) -> void:
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE


# The framed parchment box every menu of the game uses.
func _framed_box(size: Vector2) -> Control:
	var b: Control = Control.new()
	b.custom_minimum_size = size
	b.size = size
	var wall: Texture2D = _tex(GFX + "wallpaper.png")
	if wall:
		var bg: TextureRect = TextureRect.new()
		bg.texture = wall
		bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		bg.stretch_mode = TextureRect.STRETCH_TILE
		_fill(bg)
		b.add_child(bg)
	else:
		var flat: ColorRect = ColorRect.new()
		flat.color = Color(0.09, 0.08, 0.08, 0.96)
		_fill(flat)
		b.add_child(flat)
	var frame_tex: Texture2D = _tex(GFX + "Frame_shadow.png")
	if frame_tex:
		var frame: NinePatchRect = NinePatchRect.new()
		frame.texture = frame_tex
		frame.patch_margin_left = 11
		frame.patch_margin_top = 11
		frame.patch_margin_right = 11
		frame.patch_margin_bottom = 11
		_fill(frame)
		frame.offset_left = -6
		frame.offset_top = -4
		frame.offset_right = 5
		frame.offset_bottom = 8
		b.add_child(frame)
	return b


func _game_bar(tint: Color, size: Vector2, plain: bool = false) -> TextureProgressBar:
	var bar: TextureProgressBar = TextureProgressBar.new()
	bar.custom_minimum_size = size
	bar.max_value = 1.0
	bar.step = 0.001
	bar.nine_patch_stretch = true
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fill: Texture2D = null if plain else _tex("res://UI/agony_bar_fill.png")
	if fill == null:
		var img: Image = Image.create(4, 4, false, Image.FORMAT_RGBA8)
		img.fill(Color.WHITE)
		fill = ImageTexture.create_from_image(img)
	bar.texture_progress = fill
	bar.tint_progress = tint
	var back: ColorRect = ColorRect.new()
	back.color = Color.BLACK
	back.show_behind_parent = true
	_fill(back)
	bar.add_child(back)
	var frame_tex: Texture2D = _tex(GFX + "Frame.png")
	if frame_tex:
		var frame: NinePatchRect = NinePatchRect.new()
		frame.texture = frame_tex
		frame.patch_margin_left = 3
		frame.patch_margin_top = 3
		frame.patch_margin_right = 3
		frame.patch_margin_bottom = 3
		frame.show_behind_parent = true
		_fill(frame)
		frame.offset_left = -2
		frame.offset_top = -2
		frame.offset_right = 2
		frame.offset_bottom = 2
		bar.add_child(frame)
	return bar


func _button(text: String, theme_path: String, min_size: Vector2, action: Callable) -> Button:
	var b: Button = Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = min_size
	if ResourceLoader.exists(theme_path):
		b.theme = load(theme_path)
	if font:
		b.add_theme_font_override("font", font)
	b.add_theme_font_size_override("font_size", 16)
	b.pressed.connect(func():
		_click_sound()
		action.call())
	return b


func _click_sound() -> void:
	var audio: Node = coop.game("FxAudioPlayer")
	if audio and audio.has_method("play_ui_switch"):
		audio.play_ui_switch()


# ---------------------------------------------------------------- camp (overworld)

func _build_ow_button() -> void:
	ow_button = _button("CO-OP", "res://UI/button_short.tres", Vector2(105, 30), toggle_dialog)
	ow_button.tooltip_text = "Play with a friend (%s)" % OS.get_keycode_string(_toggle_key)
	ow_button.visible = false
	root.add_child(ow_button)
	ow_ready = _button("READY", "res://UI/button_short.tres", Vector2(105, 30), func(): session.set_ready(not session.my_ready))
	ow_ready.visible = false
	root.add_child(ow_ready)
	_place_ow_button(root)


func _place_ow_button(parent: Control) -> void:
	if ow_button.get_parent() != parent:
		ow_button.get_parent().remove_child(ow_button)
		parent.add_child(ow_button)
	# MENU sits in the top-right corner piece (205 px wide, 8 px from the edge); CO-OP goes to its left.
	ow_button.anchor_left = 1.0
	ow_button.anchor_right = 1.0
	ow_button.anchor_top = 0.0
	ow_button.anchor_bottom = 0.0
	ow_button.offset_left = -322.0
	ow_button.offset_right = -217.0
	ow_button.offset_top = 9.0
	ow_button.offset_bottom = 39.0
	if ow_ready.get_parent() != parent:
		ow_ready.get_parent().remove_child(ow_ready)
		parent.add_child(ow_ready)
	ow_ready.anchor_left = 1.0
	ow_ready.anchor_right = 1.0
	ow_ready.offset_left = -432.0
	ow_ready.offset_right = -327.0
	ow_ready.offset_top = 9.0
	ow_ready.offset_bottom = 39.0


# Moves the button into the game's own camp HUD once that exists, so it hides and scales with it.
func _adopt_ow_hud() -> void:
	if _ow_button_placed:
		return
	var menus: Node = coop.game("GlobalMenus")
	if menus == null:
		return
	var hud = menus.get("hudOverworld")
	if hud is Control and hud.is_inside_tree():
		_place_ow_button(hud)
		_ow_button_placed = true


func _build_banner() -> void:
	banner = _label("", 20, ORANGE)
	banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	banner.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var grad: Texture2D = _tex(GFX + "circle_gradient.png")
	if grad:
		var sb: StyleBoxTexture = StyleBoxTexture.new()
		sb.texture = grad
		sb.region_rect = Rect2(0, 0, 64, 64)
		sb.expand_margin_left = 80.0
		sb.expand_margin_right = 80.0
		sb.expand_margin_top = 14.0
		sb.expand_margin_bottom = 20.0
		sb.modulate_color = Color(0, 0, 0, 0.55)
		banner.add_theme_stylebox_override("normal", sb)
	banner.anchor_left = 0.5
	banner.anchor_right = 0.5
	banner.offset_left = -230.0
	banner.offset_right = 230.0
	banner.offset_top = 92.0
	banner.offset_bottom = 122.0
	banner.visible = false
	root.add_child(banner)
	revive_bar = _game_bar(GOLD, Vector2(180, 6), true)
	revive_bar.anchor_left = 0.5
	revive_bar.anchor_right = 0.5
	revive_bar.offset_left = -90.0
	revive_bar.offset_right = 90.0
	revive_bar.offset_top = 130.0
	revive_bar.offset_bottom = 136.0
	revive_bar.visible = false
	root.add_child(revive_bar)


# ---------------------------------------------------------------- dialog

func _build_dialog() -> void:
	dialog = ColorRect.new()
	dialog.color = Color(0, 0, 0, 0.5)
	dialog.set_anchors_preset(Control.PRESET_FULL_RECT)
	dialog.mouse_filter = Control.MOUSE_FILTER_STOP
	dialog.visible = false
	root.add_child(dialog)
	box = _framed_box(Vector2(392, 420))
	box.anchor_left = 0.5
	box.anchor_right = 0.5
	box.anchor_top = 0.5
	box.anchor_bottom = 0.5
	box.offset_left = -196.0
	box.offset_right = 196.0
	box.offset_top = -210.0
	box.offset_bottom = 210.0
	dialog.add_child(box)
	var col: VBoxContainer = VBoxContainer.new()
	col.set_anchors_preset(Control.PRESET_FULL_RECT)
	col.offset_left = 24.0
	col.offset_right = -24.0
	col.offset_top = 6.0
	col.offset_bottom = -22.0
	col.add_theme_constant_override("separation", 5)
	box.add_child(col)
	var title: Label = _label("Co-op", 20)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.custom_minimum_size = Vector2(0, 40)
	col.add_child(title)
	steps = RichTextLabel.new()
	steps.bbcode_enabled = true
	steps.fit_content = true
	steps.scroll_active = false
	steps.mouse_filter = Control.MOUSE_FILTER_IGNORE
	steps.size_flags_vertical = Control.SIZE_EXPAND_FILL
	if font:
		steps.add_theme_font_override("normal_font", font)
	steps.add_theme_font_size_override("normal_font_size", 16)
	steps.add_theme_color_override("font_shadow_color", Color.BLACK)
	col.add_child(steps)
	footer = _label("", 13, Color(0.75, 0.72, 0.66))
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	footer.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(footer)
	var long_theme: String = "res://UI/button_long.tres"
	btn_main = _button("", long_theme, Vector2(256, 28), _on_main_pressed)
	btn_difficulty = _button("", long_theme, Vector2(256, 28), _cycle_difficulty)
	btn_xp = _button("", long_theme, Vector2(256, 28), _cycle_xp)
	btn_rejoin = _button("REJOIN LAST LOBBY", long_theme, Vector2(256, 28), func(): net.rejoin())
	btn_leave = _button("LEAVE LOBBY", long_theme, Vector2(256, 28), func(): net.leave())
	var btn_close: Button = _button("CLOSE", long_theme, Vector2(256, 28), toggle_dialog)
	for b in [btn_main, btn_rejoin, btn_difficulty, btn_xp, btn_leave, btn_close]:
		b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		col.add_child(b)


func toggle_dialog() -> void:
	dialog.visible = not dialog.visible
	var menus: Node = coop.game("GlobalMenus")
	if menus and menus.has_method("set_modal_dialog_open"):
		menus.set_modal_dialog_open(dialog, dialog.visible)
	_update_dialog()


func _on_main_pressed() -> void:
	if net.lobby_id == 0:
		net.host(true)
	elif net.is_host:
		net.invite()
	else:
		session.set_ready(not session.my_ready)
	_update_dialog()


func _cycle_xp() -> void:
	if net.lobby_id != 0 and not net.is_host:
		return
	session.xp_rule = (session.xp_rule + 1) % 2
	session._send_cfg()
	_update_dialog()


func _cycle_difficulty() -> void:
	if net.lobby_id != 0 and not net.is_host:
		return
	session.difficulty = (session.difficulty + 1) % 3
	session._send_cfg()
	_update_dialog()


func _step(index: int, current: int, text: String) -> String:
	var color: String = DIM
	var mark: String = "   "
	if index < current:
		color = DONE
		mark = "+ "
	elif index == current:
		color = NOW
		mark = "> "
	return "[color=%s]%s%d. %s[/color]" % [color, mark, index, text]


func _update_dialog() -> void:
	if dialog == null:
		return
	var in_lobby: bool = net.lobby_id != 0
	var lines: Array = []
	var foot: String = ""
	if net.steam == null:
		lines.append("[color=%s]Steam is not running, so co-op is unavailable.[/color]" % NOW)
	elif session.active:
		lines.append("[color=%s]A co-op run is in progress.[/color]" % NOW)
		lines.append("")
		lines.append("[color=%s]Fallen players get back up when their partner stands next to them. Level-ups wait on the LEVEL UP button, the game never pauses.[/color]" % DIM)
	elif in_lobby and not net.is_host:
		var cur: int = 1
		if net.connected:
			cur = 4 if session.my_ready else 2
		lines.append(_step(1, cur, "Join %s's lobby" % net.peer_name))
		lines.append(_step(2, cur, "Choose your hero at the camp"))
		lines.append(_step(3, cur + (1 if cur == 2 else 0), "Press READY"))
		if session.host_in_run:
			lines.append(_step(4, cur, "%s is in a run. READY takes you straight into it" % net.peer_name))
		else:
			lines.append(_step(4, cur, "%s enters the Halls and you follow" % net.peer_name))
	else:
		var current: int = 1
		if in_lobby:
			current = 2
			if net.connected:
				current = 4 if session.partner_ready else 3
		lines.append(_step(1, current, "Host a lobby"))
		lines.append(_step(2, current, "Invite your friend through Steam"))
		lines.append(_step(3, current, "Choose heroes. Your partner presses READY"))
		lines.append(_step(4, current, "Enter the Halls. Your partner follows"))
		if not in_lobby:
			lines.append("")
			lines.append("[color=%s]Got an invite? Accept it in Steam and you join automatically.[/color]" % DIM)
	if net.connected:
		foot = "Connected to %s  -  %d ms  -  %s  -  XP: %s" % [net.peer_name, net.ping_ms, session.DIFFICULTY_NAMES[session.difficulty], session.XP_RULE_NAMES[session.xp_rule]]
		if not net.peer_game_version.is_empty() and net.peer_game_version != coop.game_version():
			foot = "Warning: you and %s run different game versions." % net.peer_name
	elif net.creating:
		foot = "Creating lobby..."
	elif net.peer_id != 0:
		foot = "Connecting to %s..." % net.peer_name
	elif in_lobby:
		foot = "Lobby open. Waiting for your friend."
	if not net.last_error.is_empty():
		foot = net.last_error
	steps.text = "\n".join(lines)
	footer.text = foot
	var guest: bool = in_lobby and not net.is_host
	btn_main.visible = net.steam != null and not session.active and (not in_lobby or (net.is_host and net.peer_id == 0) or (guest and net.connected))
	btn_main.text = "HOST GAME"
	if guest:
		btn_main.text = "NOT READY" if session.my_ready else "READY"
	elif in_lobby:
		btn_main.text = "INVITE FRIEND"
	btn_xp.visible = net.steam != null and (not in_lobby or net.is_host) and not session.active
	btn_xp.text = "XP: %s" % str(session.XP_RULE_NAMES[session.xp_rule]).to_upper()
	btn_rejoin.visible = net.steam != null and not in_lobby and net.last_lobby != 0
	btn_main.disabled = net.creating
	btn_difficulty.visible = net.steam != null and (not in_lobby or net.is_host) and not session.active
	btn_difficulty.text = "DIFFICULTY: %s" % str(session.DIFFICULTY_NAMES[session.difficulty]).to_upper()
	btn_leave.visible = in_lobby


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == _toggle_key:
			toggle_dialog()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_ESCAPE and dialog.visible:
			toggle_dialog()
			get_viewport().set_input_as_handled()


# ---------------------------------------------------------------- run HUD

func _build_hud() -> void:
	partner_box = _framed_box(Vector2(150, 46))
	partner_box.position = Vector2(float(coop.cfg["hud_x"]), float(coop.cfg["hud_y"]))
	partner_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	partner_box.visible = false
	root.add_child(partner_box)
	partner_name = _label("", 14, BLUE)
	partner_name.position = Vector2(10, 3)
	partner_name.size = Vector2(96, 18)
	partner_name.clip_text = true
	partner_box.add_child(partner_name)
	partner_info = _label("", 13, Color(0.85, 0.82, 0.75))
	partner_info.position = Vector2(84, 4)
	partner_info.size = Vector2(58, 18)
	partner_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	partner_box.add_child(partner_info)
	partner_bar = _game_bar(Color(0.78, 0.13, 0.1), Vector2(130, 7), true)
	partner_bar.position = Vector2(10, 28)
	partner_bar.size = Vector2(130, 7)
	partner_box.add_child(partner_bar)

	pointer = Control.new()
	pointer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pointer.visible = false
	root.add_child(pointer)
	pointer_arrow = Polygon2D.new()
	pointer_arrow.polygon = PackedVector2Array([Vector2(14, 0), Vector2(-8, -9), Vector2(-3, 0), Vector2(-8, 9)])
	pointer_arrow.color = BLUE
	var outline: Line2D = Line2D.new()
	outline.points = PackedVector2Array([Vector2(14, 0), Vector2(-8, -9), Vector2(-3, 0), Vector2(-8, 9), Vector2(14, 0)])
	outline.width = 1.5
	outline.default_color = Color(0, 0, 0, 0.9)
	pointer_arrow.add_child(outline)
	pointer.add_child(pointer_arrow)
	var tag: Label = _label("", 12, BLUE)
	tag.name = "Tag"
	tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tag.size = Vector2(120, 16)
	tag.position = Vector2(-60, 16)
	pointer.add_child(tag)


func _process(delta: float) -> void:
	_refresh += delta
	if _refresh >= 0.25:
		_refresh = 0.0
		_adopt_ow_hud()
		if dialog.visible:
			_update_dialog()
		var gs: Node = coop.game("GameState")
		var overworld: bool = gs != null and int(gs.get("CurrentState")) == session.st("Overworld")
		ow_button.visible = overworld
		ow_button.modulate = Color(0.75, 0.9, 1.0) if net.connected else Color.WHITE
		ow_ready.visible = overworld and net.connected and not net.is_host
		ow_ready.text = "NOT READY" if session.my_ready else "READY"
		ow_ready.modulate = Color(0.7, 1.0, 0.7) if session.my_ready else Color(1.0, 0.9, 0.6)
		_update_banner(overworld)
	_update_hud()


func _update_banner(overworld: bool) -> void:
	var text: String = ""
	var color: Color = ORANGE
	revive_bar.visible = false
	if session.notice_time > 0.0:
		text = session.notice
	elif session.active and session.partner_in_run:
		if session.me_down:
			text = "You are a ghost. %s can revive you at your grave." % net.peer_name
			color = Color(0.95, 0.35, 0.3)
			revive_bar.visible = float(session.partner.get("rev", 0.0)) > 0.0
			revive_bar.value = float(session.partner.get("rev", 0.0))
		elif session.partner_down:
			text = "%s has fallen! Stand on their grave to revive them." % net.peer_name
			color = Color(0.95, 0.35, 0.3)
			revive_bar.visible = session.revive_progress > 0.0
			revive_bar.value = session.revive_progress
		elif session.in_menu and not session._menu_expired:
			text = "Protected for %d s" % ceili(session.menu_time)
			color = GOLD
	elif overworld and net.lobby_id != 0 and not dialog.visible:
		if not net.connected:
			text = "Lobby open. Waiting for your friend..."
		elif net.is_host:
			if session.partner_ready:
				text = "%s is ready. Enter the Halls to begin!" % net.peer_name
			else:
				text = "Waiting for %s to press READY..." % net.peer_name
		elif not session.my_ready:
			text = "Choose your hero, then press READY (top right)."
		elif session.host_in_run:
			text = "Joining %s's run..." % net.peer_name
		else:
			text = "Ready. Waiting for %s to enter the Halls..." % net.peer_name
	banner.text = text
	banner.visible = not text.is_empty()
	banner.add_theme_color_override("font_color", color)
	banner.offset_top = 92.0 if overworld else 70.0
	banner.offset_bottom = banner.offset_top + 30.0
	revive_bar.offset_top = banner.offset_top + 38.0
	revive_bar.offset_bottom = revive_bar.offset_top + 6.0


func _update_hud() -> void:
	var show: bool = session.active and session.partner_in_run and not session.partner.is_empty()
	partner_box.visible = show
	pointer.visible = false
	if not show:
		return
	var p: Dictionary = session.partner
	partner_name.text = net.peer_name
	partner_bar.value = clampf(float(p["hp"]) / maxf(1.0, float(p["maxhp"])), 0.0, 1.0)
	if session.partner_down:
		partner_info.text = "DOWN"
		partner_info.add_theme_color_override("font_color", Color(0.95, 0.35, 0.3))
	else:
		partner_info.text = ("Lv %d" % int(p["level"])) + (" ..." if (int(p["flags"]) & 2) != 0 else "")
		partner_info.add_theme_color_override("font_color", Color(0.85, 0.82, 0.75))
	_update_pointer(p["pos"])


func _update_pointer(world_pos: Vector2) -> void:
	var world: Node = session.world
	if world == null or not is_instance_valid(world) or not world.is_inside_tree():
		return
	var vp_size: Vector2 = world.get_viewport().get_visible_rect().size
	if vp_size.x <= 0.0 or vp_size.y <= 0.0:
		return
	var n: Vector2 = (world.get_canvas_transform() * world_pos) / vp_size
	if n.x >= 0.0 and n.x <= 1.0 and n.y >= 0.0 and n.y <= 1.0:
		return
	var ui_size: Vector2 = root.size
	# keep clear of the 120 px HUD bars on both sides
	var lo: Vector2 = Vector2(150, 40)
	var hi: Vector2 = ui_size - Vector2(150, 56)
	pointer.position = (n * ui_size).clamp(lo, hi)
	pointer_arrow.rotation = (n - Vector2(0.5, 0.5)).angle()
	pointer.get_node("Tag").text = net.peer_name
	pointer.visible = true
