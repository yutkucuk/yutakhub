extends Node
# Wait, They Can Climb?! co-op mod loader (yutak). Loaded through override.cfg next to the game exe.
const VERSION: String = "2.0.0"
const GAME_VERSION := "0.9.9"
const PACK := "wtcc_coop.pck"

static var _ok := false
static var _msg := ""

static func _static_init() -> void:
	var ver := str(ProjectSettings.get_setting("application/config/version", ""))
	if ver != GAME_VERSION:
		_msg = "Co-op mod: game version %s is not supported (mod is for %s). Mod disabled." % [ver, GAME_VERSION]
		return
	var dir: String = (load_path() as String).get_base_dir()
	var pack := dir.path_join(PACK)
	if not FileAccess.file_exists(pack):
		_msg = "Co-op mod: %s not found." % pack
		return
	if not ProjectSettings.load_resource_pack(pack, true):
		_msg = "Co-op mod: could not load %s." % pack
		return
	_ok = true

static func load_path() -> String:
	var p := str(ProjectSettings.get_setting("autoload/CoopBoot", ""))
	return p.trim_prefix("*")

func _ready() -> void:
	if _ok:
		var s = load("res://coop/net.gd")
		if s != null:
			var n: Node = s.new()
			n.name = "Coop"
			get_tree().root.add_child.call_deferred(n)
			return
		_msg = "Co-op mod: could not load the co-op script."
	if _msg != "":
		push_warning(_msg)
		var layer := CanvasLayer.new()
		layer.layer = 100
		var l := Label.new()
		l.text = _msg
		l.position = Vector2(14, 8)
		l.add_theme_font_size_override("font_size", 18)
		l.add_theme_color_override("font_color", Color(1, 0.6, 0.4))
		layer.add_child(l)
		add_child(layer)
		get_tree().create_timer(12.0).timeout.connect(layer.queue_free)
