LAMPWARDEN  -  v1.5.0
=====================
Night has fallen. Keep the Beacon lit against whatever comes out of the dark.
Solo, or online co-op for two.

The game is in English by default. Turkish: SETTINGS > Language > Türkçe.
(Türkçe açıklama: BENIOKU.txt)

STARTING
  Double-click Lampwarden.exe. Keep all the files in this folder together.
  If Windows warns about an unknown publisher: More info > Run anyway.

CONTROLS
  WASD        move                   Mouse        aim (weapons fire on their own)
  SPACE       dash                   Q            your hero's ability
  TAB / B     shop (between waves)   F            ready / start the wave
  E           pick and place turret  Left click   place / click a placed turret: upgrade, move, sell
  R           repair the damaged turret you are standing next to
  Right click cancel                 Wheel        zoom
  ENTER       chat (co-op)           ESC          menu          F11  fullscreen
  F10         hide / show the whole interface (for screenshots and video)

CO-OP (2 players)
  Both players need the same version.
  With Steam:
    1) Both start the game while Steam is running.
    2) One: CO-OP > "Host game (Steam invite)".
    3) The other: CO-OP > "Join my friend's game (Steam)".
    Note: Steam shows the game as "Spacewar". That is the shared ID unreleased games use
    for friend connections; it is expected.
  Without Steam, by IP:
    Host: "Host game (IP / LAN)". Guest: type the host's IP and press "Join by IP".
    From different homes the host needs UDP port 27815 forwarded (or both use a virtual
    LAN such as Radmin VPN / Hamachi).

HOW IT PLAYS
  - If the Beacon goes out, the run ends.
  - You can get back up 3 times per run. Solo you rise on your own after a while; in co-op
    your partner has to stand next to you for 3 seconds. With no revives left you are out
    until the wave ends: solo that ends the run, and so does both of you being down at once.
  - Enemies inside the lit ring go for the Beacon (and turrets in their way), even if you
    are outside it; only the ones outside the ring hunt you.
  - XP is shared. Gold, items, turrets and level-up cards are each player's own.
  - Level-up cards come at the end of the wave: one pick for every level you gained.
    You also get one card before the first wave.
  - A destroyed turret or barricade is gone. Repair a damaged one by standing next to it
    and pressing R. The shop also has "Repair all my turrets".
  - Selling a turret needs a second click, so it cannot happen by accident.
  - Shop: the padlock next to an item keeps it for the next shop (and through rerolls).
  - Wreckers, Lobbers and bosses attack turrets. A red ring on the ground means a bomb
    is about to land there.
  - THE LIT ZONE: a dashed ring surrounds the Beacon. Outside it enemies notice you from
    far away, run faster and hit harder.
  - GENERATORS: four generators in the corners power the street lamps. They break down
    during waves (more often on higher difficulties). Stand next to a broken one for about
    4 seconds to repair it. In the dark, enemies are faster, tougher and hit harder.
  - Spitters and Lobbers keep their distance and back away when you close in.
  - Your items are listed in the shop (TAB) instead of on the screen.
  - Most items boost one thing and weaken another. Prices rise every wave and with every
    purchase.
  - Some nights are special (Blood Moon, Blackout, Siege...). TAKE THE DARE in the shop
    makes the next wave harder; clear it for an item and gold.
  - A boss every 5 waves. After wave 20, endless mode opens.

Save file:  %APPDATA%\Lampwarden\save.json
(Progress from "Son Işık" 1.2.0 and earlier is carried over on first start.)

CREDITS
  A game by yutku, built together with Claude.
  Sorcerer character design: Beren
  Icons: game-icons.net by Lorc, Delapouite and contributors, CC BY 3.0 (recoloured)
         https://creativecommons.org/licenses/by/3.0/
  Fonts: Quicksand (SIL Open Font License), DejaVu Sans
  Made with Godot Engine (MIT License), GodotSteam (MIT License)
